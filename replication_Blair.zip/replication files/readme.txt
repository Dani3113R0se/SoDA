** Replication Files for "Predicting Local Violence" **
by Blair, Blattman, and Hartmann. 2016.
***************************************

This folder contains all data and code needed to replicate 
tables in the paper and online appendix. For a summary of 
the dataset, see "data_documentation.txt".

To replicate the all tables, run:

code/CoRE Master Analysis.R

after changing the local directory in line 6. All other 
directories (input and output) designated relative to the
'replication files' folder. The master analysis file contains
very little code, but sources .R files that produce each table.

While the entire code can be run at once, that is not advised, 
as it will take days to run. Rather, the Master file serves as 
a guide to which code maps to which tables and graphs, and the
order in which files should be run. 

