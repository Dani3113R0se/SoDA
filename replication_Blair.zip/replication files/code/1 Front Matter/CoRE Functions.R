# Define function that calculates error rates
error.rates <- function(yraw,yhatraw) {
  
  y <- as.matrix(yraw)
  yhat <- as.matrix(yhatraw)
  
  false.pos <- colSums(ifelse(y!=yhat&yhat==1,1,0))
  fp.rate <- colSums(ifelse(y!=yhat&yhat==1,1,0))/colSums(ifelse(y==0,1,0))
  true.pos <- colSums(ifelse(y==yhat&yhat==1,1,0))
  tp.rate <- colSums(ifelse(y==yhat&yhat==1,1,0))/colSums(ifelse(y==1,1,0))
  false.neg <- colSums(ifelse(y!=yhat&yhat==0,1,0))
  fn.rate <- colSums(ifelse(y!=yhat&yhat==0,1,0))/colSums(ifelse(y==1,1,0))
  true.neg <- colSums(ifelse(y==yhat&yhat==0,1,0))
  tn.rate <- colSums(ifelse(y==yhat&yhat==0,1,0))/colSums(ifelse(y==0,1,0))
  success <- colSums(ifelse(y==yhat,1,0))
  success.rate <- colSums(ifelse(y==yhat,1,0))/nrow(y)
  fptp.ratio <-colSums(ifelse(y!=yhat&yhat==1,1,0))/colSums(ifelse(y==yhat&yhat==1,1,0))
  fntn.ratio <-colSums(ifelse(y!=yhat&yhat==0,1,0))/colSums(ifelse(y==yhat&yhat==0,1,0))
  fntp.ratio <- colSums(ifelse(y!=yhat&yhat==0,1,0))/colSums(ifelse(y==yhat&yhat==1,1,0))
  pred.pos.rate <- colSums(yhat)/nrow(y)
  fn.all.ratio <- colSums(ifelse(y!=yhat&yhat==0,1,0))/nrow(y)
  er <- list(false.pos=false.pos,fp.rate=fp.rate,true.pos=true.pos,
             tp.rate=tp.rate,false.neg=false.neg,fn.rate=fn.rate,
             true.neg=true.neg,tn.rate=tn.rate,success=success,
             success.rate=success.rate,fptp.ratio=fptp.ratio,
             fntn.ratio=fntn.ratio,fntp.ratio=fntp.ratio,
             pred.pos.rate=pred.pos.rate, fn.all.ratio=fn.all.ratio)
  return(er)
}

## Function that does linear interpolations for ROCs
lin.interp <- function(x) {
  N = length(x)
  out = x
  for (n in 1:N) {
    if (is.na(out[n])) {
      start = n - 1
      start.val = out[n-1]
      z = n
      while (is.na(out[z])) {
        z = z+1
      }
      finish = z
      finish.val = out[z]
      l = finish - start
      l.val = finish.val - start.val
      for (i in 1:(l-1)) {
        out[n+i-1] = start.val + i*(l.val/l)
      }
    }
  }
  return(out)
}