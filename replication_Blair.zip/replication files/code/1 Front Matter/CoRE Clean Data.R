## Define list of predictors
predictors <- c("sctownpop",
                "sctownhh",       
                "scnum_tribes",     
                "sctownmusl_percap",       
                "scmosquesdum",        
                "scmuslim",     
                "scprop_stranger",       
                "sctownstrg_percap",     
                "scprop_domgroup",     
                "scexcom",     
                "sctownexcm_percap",     
                "sctownretn_percap",     
                "scprop_under30",     
                "scprop_male",     
                "scedulevel",     
                "scprop_noeduc",     
                "scprop_anypeace",     
                "scgroup_prtcptn",      
                "scpubcontr",     
                "scsafecommdum",     
                "scciviccommdum",     
                "scoll_action_add",     
                "scngodependent",    
                "scgovtdependent",     
                "cequity_comm",     
                "scpolicourtscorr",       
                "screlmarry",        
                "scmslmnolead",     
                "sctribeviolent",     
                "sctribedirty",      
                "scmnrt_ldrshp",     
                "sccrime_scale",          
                "scviol_scale",         
                "sclandconf_scale",     
                "scany_majorconf",        
                "sctownnlnd_percap",        
                "scnolandnofarm",    
                "scfarmocc",        
                "scunemployed",        
                "scwealthindex",     
                "scwealth_inequality",      
                "scviol_experienced",        
                "scviol_part",     
                "scanylndtake",         
                "scdisp_ref",         
                "sfacilities",     
                "sstate_presence",         
                "sfreq_visits",         
                "sremote",     
                "scmobilec",        
                "scradio_low",         
                "sctot_resources",     
                "scmeanprice_above75",
                "scpdis_shock",         
                "scpani_shock",         
                "scpcrop_shock")

var.labels <- c("Town Population",
                "Number of Households",
                "Number of Tribes",
                "Percent Muslims (Leader)",
                "Has Mosque (Resident)",
                "Percent Muslims (Resident)",
                "Percent Non-Native (Residents)",
                "Percent Non-Native (Leader)",
                "Percent in Dominant Group",
                "Percent Ex-Combatants (Residents)",
                "Percent Ex-Combatants (Leader)",
                "Percent returned for Internal Displacement",     
                "Percent under 30",     
                "Percent Male",     
                "Mean Educational Attainment",     
                "Percent With No Education",     
                "Proportion Receiving Any Peace Training",     
                "Group Participation (0-9)",      
                "Percent Who Contribute to Public Facilities",     
                "Percent Saying Town is Safe at Night",     
                "Percent Saying Neighbors Are Helpful",     
                "Collective Public Goods",     
                "Percent Who Rely on NGOs",    
                "Percent Who Rely on Government",     
                "Perceived Equity in Institutions",     
                "Percent Describing Police/Courts as Corrupt",       
                "Percent Accepting Inter-Racial Marriage",        
                "Percent Who Say Muslims Shouldn't Be Leaders",     
                "Percent Believing other Tribes are Violent",     
                "Percent Believing Other Tribes are Dirty",      
                "Minority Tribe in Town Leadership",     
                "Percent Reporting Burglary or Robbery",          
                "Percent Reporting Assault",         
                "Percent Reporting Any Land Conflict",     
                "Any Violent Event",        
                "Percent of Town Landless (Leader)",        
                "Percent of Town Landless (Residents)",    
                "Percent of Town Farmers",        
                "Unemployment Rate",        
                "Wealth Index",     
                "S.D. of Wealth Index In Town",      
                "Exposure to War Violence",        
                "Participation in War Violence",     
                "Percent Reporting Loss of Land During War",         
                "Percent Displaced During War",         
                "Social Services in Town",     
                "Police or Magistrate in Town",         
                "Frequency of Police/ NGO Visits",         
                "Town>1 Hour from Road",     
                "Mobile Phone Coverage",        
                "Less than 2 Radio Stations",         
                "Natural Resources In 2 Hours",     
                "Commodity Price Index",
                "Percent Affected By Human Disease",         
                "Percent Affected By Livestock Disease",         
                "Percent Affected By Crop Failure"
)

## Define matrix of wave 1 risk factors
covars_b <- cbind(
  core_comm_2012$ctownpop_bl,
  core_comm_2012$ctownhh_bl,       
  core_comm_2012$cnum_tribes_bc,     
  core_comm_2012$ctownmusl_percap_bl,       
  core_comm_2012$cmosquesdum_bl,        
  core_comm_2012$cmuslim_bc,     
  core_comm_2012$cprop_stranger_bc,       
  core_comm_2012$ctownstrg_percap_bl,     
  core_comm_2012$cprop_domgroup_bc,     
  core_comm_2012$cexcom_bc,     
  core_comm_2012$ctownexcm_percap_bl,     
  core_comm_2012$ctownretn_percap_bl,     
  core_comm_2012$cprop_under30_bc,     
  core_comm_2012$cprop_male_bc,     
  core_comm_2012$cedulevel_bc,     
  core_comm_2012$cprop_noeduc_bc,     
  core_comm_2012$cprop_anypeace_bc,     
  core_comm_2012$cgroup_prtcptn_bc,      
  core_comm_2012$cpubcontr_bc,     
  core_comm_2012$csafecommdum_bc,     
  core_comm_2012$cciviccommdum_bc,     
  core_comm_2012$coll_action_add_bl,     
  core_comm_2012$cngodependent_bc,    
  core_comm_2012$cgovtdependent_bc,     
  core_comm_2012$cequity_comm_bc,     
  core_comm_2012$cpolicourtscorr_bc,       
  core_comm_2012$crelmarry_bc,        
  core_comm_2012$cmslmnolead_bc,     
  core_comm_2012$ctribeviolent_bc,     
  core_comm_2012$ctribedirty_bc,      
  core_comm_2012$cmnrt_ldrshp_bl,     
  core_comm_2012$ccrime_scale_bc,          
  core_comm_2012$cviol_scale_bc,         
  core_comm_2012$clandconf_scale_bc,     
  core_comm_2012$cany_majorconf_bl,        
  core_comm_2012$ctownnlnd_percap_bl,        
  core_comm_2012$cnolandnofarm_bc,    
  core_comm_2012$cfarmocc_bc,        
  core_comm_2012$cunemployed_bc,        
  core_comm_2012$cwealthindex_bc,     
  core_comm_2012$cwealth_inequality_bc,      
  core_comm_2012$cviol_experienced_bc,        
  core_comm_2012$cviol_part_bc,     
  core_comm_2012$canylndtake_bc,         
  core_comm_2012$cdisp_ref_bc,         
  core_comm_2012$cfacilities_bl,     
  core_comm_2012$cstate_presence_bl,         
  core_comm_2012$cfreq_visits_bl,         
  core_comm_2012$cremote_bl,     
  core_comm_2012$cmobilec_bl,        
  core_comm_2012$cradio_low_bl,         
  core_comm_2012$ctot_resources_bl,     
  core_comm_2012$cmeanprice_above75_bl,
  core_comm_2012$cpdis_shock_bl,         
  core_comm_2012$cpani_shock_bl,         
  core_comm_2012$cpcrop_shock_bl
)
# NOTE: The following risk factors are no longer included in the analysis:
# l.cpropdomgroup: The questions required to construct this variable were excluded from the endline survey
# ctribe_palava: The questions required to construct this variable were excluded from the endline survey

## Verify dimensions of wave 1 risk factors matrix
dim(covars_b)

## Assign column names to wave 1 risk factors matrix
colnames(covars_b) <- c(		
  "ctownpop_bl",
  "ctownhh_bl",       
  "cnum_tribes_bc",     
  "ctownmusl_percap_bl",       
  "cmosquesdum_bl",        
  "cmuslim_bc",     
  "cprop_stranger_bc",       
  "ctownstrg_percap_bl",     
  "cprop_domgroup_bc",     
  "cexcom_bc",     
  "ctownexcm_percap_bl",     
  "ctownretn_percap_bl",     
  "cprop_under30_bc",     
  "cprop_male_bc",     
  "cedulevel_bc",     
  "cprop_noeduc_bc",     
  "cprop_anypeace_bc",     
  "cgroup_prtcptn_bc",      
  "cpubcontr_bc",     
  "csafecommdum_bc",     
  "cciviccommdum_bc",     
  "coll_action_add_bl",     
  "cngodependent_bc",    
  "cgovtdependent_bc",     
  "cequity_comm_bc",     
  "cpolicourtscorr_bc",       
  "crelmarry_bc",        
  "cmslmnolead_bc",     
  "ctribeviolent",     
  "ctribedirty",      
  "cmnrt_ldrshp",     
  "ccrime_scale_bc",          
  "cviol_scale_bc",         
  "clandconf_scale_bc",     
  "cany_majorconf_bl",        
  "ctownnlnd_percap_bl",        
  "cnolandnofarm_bc",    
  "cfarmocc_bc",        
  "cunemployed_bc",        
  "cwealthindex_bc",     
  "cwealth_inequality_bc",      
  "cviol_experienced_bc",        
  "cviol_part_bc",     
  "canylndtake_bc",         
  "cdisp_ref_bc",         
  "facilities_bl",     
  "state_presence_bl",         
  "freq_visits_bl",         
  "remote_bl",     
  "cmobilec_bl",        
  "cradio_low_bl",         
  "ctot_resources_bl",     
  "cmeanprice_above75_bl",
  "cpdis_shock_bl",         
  "cpani_shock_bl",         
  "cpcrop_shock_bl"
)

## Define matrix of wave 2 risk factors
covars_e <- cbind(
  core_comm_2012$ctownpop_el,
  core_comm_2012$ctownhh_el,       
  core_comm_2012$cnum_tribes_ec,     
  core_comm_2012$ctownmusl_percap_el,       
  core_comm_2012$cmosquesdum_el,        
  core_comm_2012$cmuslim_ec,     
  core_comm_2012$cprop_stranger_ec,       
  core_comm_2012$ctownstrg_percap_el,     
  core_comm_2012$cprop_domgroup_ec,     
  core_comm_2012$cexcom_ec,     
  core_comm_2012$ctownexcm_percap_el,     
  core_comm_2012$ctownretn_percap_el,     
  core_comm_2012$cprop_under30_ec,     
  core_comm_2012$cprop_male_ec,     
  core_comm_2012$cedulevel_ec,     
  core_comm_2012$cprop_noeduc_ec,     
  core_comm_2012$cprop_anypeace_ec,     
  core_comm_2012$cgroup_prtcptn_ec,      
  core_comm_2012$cpubcontr_ec,     
  core_comm_2012$csafecommdum_ec,     
  core_comm_2012$cciviccommdum_ec,     
  core_comm_2012$coll_action_add_el,     
  core_comm_2012$cngodependent_ec,    
  core_comm_2012$cgovtdependent_ec, 
  core_comm_2012$cequity_comm_ec,     
  core_comm_2012$cpolicourtscorr_ec,       
  core_comm_2012$crelmarry_ec,        
  core_comm_2012$cmslmnolead_ec,     
  core_comm_2012$ctribeviolent_ec,     
  core_comm_2012$ctribedirty_ec,      
  core_comm_2012$cmnrt_ldrshp_el,     
  core_comm_2012$ccrime_scale_ec,          
  core_comm_2012$cviol_scale_ec,         
  core_comm_2012$clandconf_scale_ec,     
  core_comm_2012$cany_majorconf_el,        
  core_comm_2012$ctownnlnd_percap_el,        
  core_comm_2012$cnolandnofarm_ec,    
  core_comm_2012$cfarmocc_ec,        
  core_comm_2012$cunemployed_ec,        
  core_comm_2012$cwealthindex_ec,     
  core_comm_2012$cwealth_inequality_ec,      
  core_comm_2012$cviol_experienced_ec,        
  core_comm_2012$cviol_part_ec,     
  core_comm_2012$canylndtake_ec,         
  core_comm_2012$cdisp_ref_ec,         
  core_comm_2012$facilities_el,     
  core_comm_2012$state_presence_el,         
  core_comm_2012$freq_visits_el,         
  core_comm_2012$remote_el,     
  core_comm_2012$cmobilec_el,        
  core_comm_2012$cradio_low_el,         
  core_comm_2012$ctot_resources_el,     
  core_comm_2012$cmeanprice_above75_el,
  core_comm_2012$cpdis_shock_el,         
  core_comm_2012$cpani_shock_el,         
  core_comm_2012$cpcrop_shock_el
)
covars_e <- data.frame(covars_e)

## Verify dimensions of risk factors matrix
dim(covars_e)

## Assign column names to risk factors matrix
colnames(covars_e) <- c(
  "ctownpop_el",
  "ctownhh_el",       
  "cnum_tribes_ec",     
  "ctownmusl_percap_el",       
  "cmosquesdum_el",        
  "cmuslim_ec",     
  "cprop_stranger_ec",       
  "ctownstrg_percap_el",     
  "cprop_domgroup_ec",     
  "cexcom_ec",     
  "ctownexcm_percap_el",     
  "ctownretn_percap_el",     
  "cprop_under30_ec",     
  "cprop_male_ec",     
  "cedulevel_ec",     
  "cprop_noeduc_ec",     
  "cprop_anypeace_ec",     
  "cgroup_prtcptn_ec",      
  "cpubcontr_ec",     
  "csafecommdum_ec",     
  "cciviccommdum_ec",     
  "coll_action_add_el",     
  "cngodependent_ec",    
  "cgovtdependent_ec",     
  "cequity_comm_bc",     
  "cpolicourtscorr_ec",       
  "crelmarry_ec",        
  "cmslmnolead_ec",     
  "ctribeviolent",     
  "ctribedirty",      
  "cmnrt_ldrshp",     
  "ccrime_scale_ec",          
  "cviol_scale_ec",         
  "clandconf_scale_ec",     
  "cany_majorconf_el",        
  "ctownnlnd_percap_el",        
  "cnolandnofarm_ec",    
  "cfarmocc_ec",        
  "cunemployed_ec",        
  "cwealthindex_ec",     
  "cwealth_inequality_ec",      
  "cviol_experienced_ec",        
  "cviol_part_ec",     
  "canylndtake_ec",         
  "cdisp_ref_ec",         
  "facilities_el",     
  "state_presence_el",         
  "freq_visits_el",         
  "remote_el",     
  "cmobilec_el",        
  "cradio_low_el",         
  "ctot_resources_el",     
  "cmeanprice_above75_el",
  "cpdis_shock_el",         
  "cpani_shock_el",         
  "cpcrop_shock_el"    
)

## Standardize wave 1 risk factors
## Define matrix of standardized wave 1 risk factors, excluding dummies
scovars_b <- covars_b
colnames(scovars_b) <- predictors

## Identify wave 1 dummies
holder <- c()
for(i in 1:dim(scovars_b)[2]){
  holder[i] <- length(table(scovars_b[,i]))<=2
}
non.dummy <- which(abs(as.numeric(holder)-1)==1)
dummy <- which(abs(as.numeric(holder))==1)

## Populate matrix of standardized wave 1 risk factors, excluding dummies
scovars_b <- cbind(scale(scovars_b[,non.dummy]), scovars_b[,dummy])

## Verify that wave 1 standardization was successful
summary(scovars_b)

## Define matrix of wave 1 standardized risk factors, including dummies
scovars_b_all <- covars_b
colnames(scovars_b_all) <- predictors

## Get column means and standard deviations 
mean2008 <- colMeans(scovars_b_all)
sd2008 <- apply(scovars_b_all, 2, sd)

## Populate matrix of wave 1 standardized risk factors, including dummies
scovars_b_all <- scale(scovars_b_all,center = mean2008, scale = sd2008)

## Verify that wave 1 standardization was successful
summary(scovars_b_all)

# NOTE: For all variables, test1 should equal test2
## Verify dimensions of wave 1 standardized risk factor matrix
if(all.equal(dim(covars_b), dim(scovars_b_all))) cat("Good news. Standardization matrix matches original in size") else(cat("Bad news. There's a problem, check the standardization"))

## Standardize wave 2 risk factors
## Define matrix of standardized wave 2 risk factors, excluding dummies
scovars_e <- covars_e
colnames(scovars_e) <- predictors

## Identify wave 2 dummies
holder <- c()
for(i in 1:dim(scovars_e)[2]){
  holder[i] <- length(table(scovars_e[,i]))<=2
}
non.dummy <- which(abs(as.numeric(holder)-1)==1)
dummy <- which(abs(as.numeric(holder))==1)

## Populate matrix of standardized wave 2 risk factors, excluding dummies
scovars_e <- cbind(scale(scovars_e[,non.dummy]), scovars_e[,dummy])

## Verify that wave 2 standardization was successful
summary(scovars_e)

## Verify dimensions of wave 2 standardized risk factor matrix, exluding dummies
if(all.equal(dim(covars_e), dim(scovars_e))) cat("Good news. Standardization matrix matches original in size") else(cat("Bad news. There's a problem, check the standardization"))

## Define matrix of wave 2 standardized risk factors, including dummies
scovars_e_all <- covars_e
colnames(scovars_e_all) <- predictors

## Populate matrix of wave 2 standardized risk factors, including dummies
scovars_e_all <- scale(scovars_e_all)

## Verify that wave 2 standardization was successful
summary(scovars_e_all)

## Verify dimensions of wave 2 standardized risk factor matrix
if(all.equal(dim(covars_e), dim(scovars_e_all))) cat("Good news. Standardization matrix matches original in size") else(cat("Bad news. There's a problem, check the standardization"))

## Define wave 2 DVs
ytest <- core_comm_2012$cany_majorconf_el
ytest

## Define data frame with wave 2 DV and wave 1 risk factors
testframe = data.frame(ytest, 
                  core_comm_2012$commcode, 
                  scovars_b_all)
testframe_ns = data.frame(ytest, 
                       core_comm_2012$commcode, 
                       scovars_b)
testframe_disagg = data.frame(ytest, 
                              core_comm_2012$cstrikeviolent_dummy_el,
                              core_comm_2012$canytribalviolence_dummy_el,
                              core_comm_2012$cmrders_dummy_el,
                              core_comm_2012$crape_dummy_el,
                              core_comm_2012$csasycutl_dummy_el,
                              core_comm_2012$cbtklwitc_dummy_el,
                              core_comm_2012$cfightsweap_dummy_el,
                              core_comm_2012$ccoll_viol_el,
                              core_comm_2012$cinterpersonal_el,
                              core_comm_2012$ctribal_conf_el,
                              core_comm_2012$cany_ejipconf_el,
                              core_comm_2012$cany_majorconfnofights_el,
                              core_comm_2012$cintergroup_el,
                              core_comm_2012$cany_ipcollconf_el,
                              core_comm_2012$commcode,
                              scovars_b_all,
                              core_comm_2012$cany_majorconfnofights_bl,
                              core_comm_2012$cstrikeviolent_dummy_bl,
                              core_comm_2012$canytribalviolence_dummy_bl,
                              core_comm_2012$cmrders_dummy_bl,
                              core_comm_2012$crape_dummy_bl,
                              core_comm_2012$csasycutl_dummy_bl,
                              core_comm_2012$cbtklwitc_dummy_bl,
                              core_comm_2012$cfight_dummy_bl,
                              core_comm_2012$ccoll_viol_bl,
                              core_comm_2012$cinterpersonal_bl,
                              core_comm_2012$ctribal_conf_bl)
colnames(testframe_disagg)[2:15] <- c("strike","tribe","murder","rape","trial","witch","fight","collective","interpersonal","extrajudicial","xjud.ip","conf.nofights","intergroup","ip.coll")
colnames(testframe_disagg)[73:83]<- c("conf.nofights.rf","strike.rf","tribe.rf","murder.rf","rape.rf","trial.rf","witch.rf","fight.rf","collective.rf","interpersonal.rf","extrajudicial.rf")
## Redefine data frame to exclude missing observations
testframe2 = na.omit(testframe)
testframe2_ns = na.omit(testframe_ns)

## Define data frame with wave 3 DV and wave 2 risk factors
testframe_e2 = data.frame(core_comm_2012$cany_majorconf_el2, 
                     core_comm_2012$commcode, 
                     scovars_e_all)
testframe_e2_ns = data.frame(core_comm_2012$cany_majorconf_el2, 
                          core_comm_2012$commcode, 
                          scovars_e)
testframe_e2_disagg = data.frame(core_comm_2012$cany_majorconf_el2, 
                                 core_comm_2012$cstrkviol_dummy_el2,
                                 core_comm_2012$ctribviol_dummy_el2,
                                 core_comm_2012$cmrders_dummy_el2,
                                 core_comm_2012$crapes_dummy_el2,
                                 core_comm_2012$csasycutl_dummy_el2,
                                 core_comm_2012$cbtklwitc_dummy_el2,
                                 core_comm_2012$cfightsweap_dummy_el2,
                                 core_comm_2012$ccoll_viol_el2,
                                 core_comm_2012$cinterpersonal_el2,
                                 core_comm_2012$ctribal_conf_el2,
                                 core_comm_2012$cany_ejipconf_el2,
                                 core_comm_2012$cany_majorconfnofights_el2,
                                 core_comm_2012$cintergroup_el2,
                                 core_comm_2012$cany_ipcollconf_el2,
                                 core_comm_2012$commcode,
                                 scovars_e_all,
                                 core_comm_2012$cany_majorconfnofights_el,
                                 core_comm_2012$cstrkviol_dummy_el,
                                 core_comm_2012$ctribviol_dummy_el,
                                 core_comm_2012$cmrders_dummy_el,
                                 core_comm_2012$crapes_dummy_el,
                                 core_comm_2012$csasycutl_dummy_el,
                                 core_comm_2012$cbtklwitc_dummy_el,
                                 core_comm_2012$cfightsweap_dummy_el)
colnames(testframe_e2)[1] <- c("ytest")
colnames(testframe_e2_ns)[1] <- "ytest"
colnames(testframe_e2_disagg)[1] <- "ytest"
colnames(testframe_e2_disagg)[2:15] <- c("strike","tribe","murder","rape","trial","witch","fight", "collective","interpersonal","extrajudicial","xjud.ip","conf.nofights","intergroup","ip.coll")
colnames(testframe_e2_disagg)[73:80] <- c("conf.nofights.rf","strike.rf","tribe.rf","murder.rf","rape.rf","trial.rf","witch.rf","fight.rf")
## Redefine data frame to exclude missing observations
testframe2_e2 = na.omit(testframe_e2)
testframe2_e2_ns = na.omit(testframe_e2_ns)

## Define data frame with wave 3 DV and wave 1 risk factors
testframe_0812 = data.frame(core_comm_2012$cany_majorconf_el2, 
                       core_comm_2012$commcode, 
                       scovars_b_all)
dim(testframe_0812)

## Redefine data frame to exclude missing observations
testframe2_0812 = na.omit(testframe_0812)
dim(testframe2_0812)

## Define prediction formula to be used in all models
spec2010 <- as.formula(paste("ytest",paste(predictors, collapse=" + "), sep = "~", collapse=NULL))

nofights.predictors <- c(predictors[-which(predictors=="scany_majorconf")],"conf.nofights.rf")
nofightspec2010 <- as.formula(paste("conf.nofights",paste(nofights.predictors, collapse=" + "), sep = "~", collapse=NULL))

disag.rf.predictors <- c(predictors[-which(predictors=="scany_majorconf")],"strike.rf","tribe.rf","murder.rf","rape.rf","trial.rf","witch.rf","fight.rf")
disag.rf.spec2010 <-  as.formula(paste("ytest",paste(disag.rf.predictors, collapse=" + "), sep = "~", collapse=NULL))

full.predictors <- c(predictors,"conf.nofights.rf","strike.rf","tribe.rf","murder.rf","rape.rf","trial.rf","witch.rf","fight.rf")
full.var.labels <- c(var.labels,
                     "Violence excluding fights",
                     "Violent strikes or protests",
                     "Tribal Conflict",
                     "Murder",
                     "Rape",
                     "Trial by Ordeal",
                     "Witch Burning",
                     "Serious Fight")

