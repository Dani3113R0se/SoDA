## Logit ROC
##############

load("workspaces/Logitresults2010.Rdata")
load("workspaces/Logitresults2012.Rdata")

ROC_seq = seq(from = -.001, to = 1.001, by = 0.001)

## Specify number of trials		
CV.runs <- 200
graph.runs <- 20
J <- length(ROC_seq)
      
## Specify number of folds for CV     
K = 5
sampleSplit = c(0,round((nrow(testframe2)/K*c(seq(1:K)))))
## Define Vector for Results
Logit.TPs <- matrix(data = NA, nrow = J, ncol = CV.runs)
Logit.FPs <- matrix(data = NA, nrow = J, ncol = CV.runs)
      	
## Run 200 simulated out-of-sample tests					
## Note: The i loop runs CVs, the j loop tests all discrimination thresholds within each CV			
for(i in 1:CV.runs) {			
  set.seed(552+i)
  ## First generate predicted probabilities    
  ## Create prediction vector to populate
  pred.prob <- matrix(NA,nrow(testframe2))
  predictions <- matrix(NA,nrow(testframe2)) 
  ## Loop over folds
  shuffle <- sample(1:nrow(testframe2),  dim(testframe2)[1],  replace=FALSE)
  for (k in 1:K) {
    ## Divide sample
    test <- testframe2[shuffle[(sampleSplit[k]+1):(sampleSplit[k+1])],]
    train <- testframe2[-shuffle[(sampleSplit[k]+1):(sampleSplit[k+1])],]
    # Estimate Logit Model
    logit.model <- glm(spec2010, data = train, family = "binomial") 
    pred.prob[shuffle[(sampleSplit[k]+1):(sampleSplit[k+1])],] <- predict(logit.model,  test, type="response") 
  }
	    for(j in 1:J){      
        predictions <- ifelse(pred.prob>ROC_seq[j],1,0)	  
        ## Find error rates  
        errors <- error.rates(testframe2[, "ytest"], predictions)				
			  # True Positives
			  Logit.TPs[j, i]  <- errors$tp.rate						
			  # False Positives
			  Logit.FPs[j, i]  <- errors$fp.rate			
      }
}
avg.FP = seq(from = 0, to = 1, by = 0.001)
bin.TP = matrix(data = NA, nrow = 1001, ncol = CV.runs)
round.FPs <- round(Logit.FPs,2)
for (n in 1:CV.runs) {
  for (i in 1:1001) {
    j = i - 1
    find.fp <- ifelse(round.FPs[,n]==j/1000,1,0)
    bin.TP[i,n] <- mean(Logit.TPs[find.fp==1,n])
  }
  bin.TP[,n] <- lin.interp(bin.TP[,n])
}
avg.TP <- rowMeans(bin.TP)

## 2012 ROC
Logit.TPs.2012 <- c(rep(NA,J))
Logit.FPs.2012 <- c(rep(NA,J))
##
logit.full <- glm(spec2010, data = testframe2, family = "binomial")   
pred2012_Logit = as.matrix(predict(logit.full,  newx = data.matrix(testframe2_e2[, predictors]), type="response"))
for(j in 1:J){      
  predictions <- ifelse(pred2012_Logit>ROC_seq[j],1,0)    
  ## Find error rates  
  errors <- error.rates(testframe2_e2[, "ytest"], predictions)				
  # True Positives
  Logit.TPs.2012[j]  <- errors$tp.rate						
  # False Positives
  Logit.FPs.2012[j]  <- errors$fp.rate			
}

Logit.2010.ROC <- data.frame(avg.FP,avg.TP)
save(Logit.2010.ROC,file="workspaces/Logit2010ROC.RData")
Logit.2012.ROC <- data.frame(Logit.FPs.2012,Logit.TPs.2012)
save(Logit.2012.ROC,file="workspaces/Logit2012ROC.RData")

## Make graph
pdf("graphs/Logit ROC 2010.pdf",width = 7, height = 7,family = "Times")
plot(Logit.FPs[,1],
     Logit.TPs[,1],
     type = "l",
     col = "cadetblue1",
     xlim = c(0,1),
     ylim = c(0,1),
     main = "Logit ROC 2010",
     ylab = "True Positive Rate",
     xlab = "False Positive Rate"
     )
for (i in 2:graph.runs) {
  lines(Logit.FPs[,i],
       Logit.TPs[,i],
       col = c("cadetblue1")
       )
}
lines(Logit.FPs.2012,
     Logit.TPs.2012,
     type = "l",
     lwd = 2,
     col = "blue4"
)
lines(avg.FP,
      avg.TP,
      lty = "dashed",
      lwd = 2,
      col = c("blue4")
      )
abline(c(0,1),
       lty = 2
       )
points(1-Logitresults2010["specificity",],
       Logitresults2010["sensitivity",],
       pch = 19
)
text(x = 1-Logitresults2010["specificity",]-.2,
     y = Logitresults2010["sensitivity",],
     labels = "Actual 2010 Error Rate",
     pos = 2
)
segments(x0 = 1-Logitresults2010["specificity",]-.2,
         y0 = Logitresults2010["sensitivity",],
         x1 = 1-Logitresults2010["specificity",],
         y1 = Logitresults2010["sensitivity",]
         )
points(1-Logitresults2012["specificity",],
       Logitresults2012["sensitivity",],
       pch = 19
)
text(x = 1-Logitresults2012["specificity",]-.2,
     y = Logitresults2012["sensitivity",],
     labels = "Actual 2012 Error Rate",
     pos = 2
)
segments(x0 = 1-Logitresults2012["specificity",]-.2,
         y0 = Logitresults2012["sensitivity",],
         x1 = 1-Logitresults2012["specificity",],
         y1 = Logitresults2012["sensitivity",]
)
text.legend <- c("2010 Average ROC", 
                 "2012 ROC", 
                 "ROCs for 2010 CV Runs", 
                 "45 Degree Line")
cols.legend <- c("blue4","blue4","cadetblue1","black")
stys.legend <- c(2,1,1,2)
wds.legend <- c(2,2,1,1)
legend(.6,
       .4,
       text.legend,
       lty = stys.legend,
       col = cols.legend,
       lwd = wds.legend
)
## End graph
dev.off()
