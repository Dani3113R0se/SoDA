## SECTION 3.0: Random Forests ##
## SECTION 3.1: SIMULATED OUT-OF-SAMPLE TEST ##
load("workspaces/RFresults2010.Rdata")
load("workspaces/RFresults2012.Rdata")
load("workspaces/rf.seed.RData")
ROC_seq = seq(from = 0, to = 1, by = 0.001)

## Specify number of trials		
CV.runs <- 200
graph.runs <- 20
J <- length(ROC_seq)
      
## Specify number of folds for CV     
K = 5
sampleSplit = c(0,round((nrow(testframe2)/K*c(seq(1:K)))))
## Define Vector for Results
RF.TPs <- matrix(data = NA, nrow = J, ncol = CV.runs)
RF.FPs <- matrix(data = NA, nrow = J, ncol = CV.runs)
      	
## Run 200 simulated out-of-sample tests					
## Note: The i loop runs CVs, the j loop tests all discrimination thresholds within each CV			
for(i in 1:CV.runs) {			
			set.seed(52+i)
	    ## First generate predicted probabilities    
      ## Create prediction vector to populate
	    pred.prob <- matrix(NA,nrow(testframe2))
      predictions <- matrix(NA,nrow(testframe2)) 
      ## Loop over folds
	    shuffle <- sample(1:nrow(testframe2),  dim(testframe2)[1],  replace=FALSE)	  
      for (k in 1:K) {      
      ## Divide sample        
        test <- testframe2[shuffle[(sampleSplit[k]+1):(sampleSplit[k+1])],]
        train <- testframe2[-shuffle[(sampleSplit[k]+1):(sampleSplit[k+1])],]        
	      fit <- randomForest(spec2010, 
				  type = regression, importance = TRUE, 
          na.action = na.omit, ntree = 1000, maxnodes = 5, 
          sampsize = 24, 
          replace = FALSE, do.trace = FALSE , 
          data = train, forest = TRUE   
		    	)	
        pred.prob[shuffle[(sampleSplit[k]+1):(sampleSplit[k+1])],] <- as.numeric(predict(fit, newdata = data.matrix(test), type="response"))  
      }	  
	    for(j in 1:J){      
        predictions <- ifelse(pred.prob>ROC_seq[j],1,0)	  
        ## Find error rates  
        errors <- error.rates(testframe2[, "ytest"], predictions)				
			  # True Positives
			  RF.TPs[j, i]  <- errors$tp.rate						
			  # False Positives
			  RF.FPs[j, i]  <- errors$fp.rate			
      }
}
avg.FP = seq(from = 0, to = 1, by = 0.001)
bin.TP = matrix(data = NA, nrow = 1001, ncol = CV.runs)
round.FPs <- round(RF.FPs,2)
for (n in 1:CV.runs) {
  for (i in 1:1001) {
    j = i - 1
    find.fp <- ifelse(round.FPs[,n]==j/1000,1,0)
    bin.TP[i,n] <- mean(RF.TPs[find.fp==1,n])
  }
  bin.TP[,n] <- lin.interp(bin.TP[,n])
}
avg.TP <- rowMeans(bin.TP)

## 2012 ROC
RF.TPs.2012 <- c(rep(NA,J))
RF.FPs.2012 <- c(rep(NA,J))
##
set.seed(rf.seed)
rf.full <- randomForest(spec2010, 
                        type = regression, importance = TRUE, 
                        na.action = na.omit, ntree = 1000, maxnodes = 5, 
                        sampsize = 24, 
                        replace = FALSE, do.trace = FALSE , 
                        data = testframe2, forest = TRUE   
)  
pred2012_RF = as.numeric(predict(rf.full, newdata = data.matrix(testframe2_e2[, predictors])))
for(j in 1:J){      
  predictions <- ifelse(pred2012_RF>ROC_seq[j],1,0)    
  ## Find error rates  
  errors <- error.rates(testframe2_e2[, "ytest"], predictions)				
  # True Positives
  RF.TPs.2012[j]  <- errors$tp.rate						
  # False Positives
  RF.FPs.2012[j]  <- errors$fp.rate			
}

RF.2010.ROC <- data.frame(avg.FP,avg.TP)
save(RF.2010.ROC,file="workspaces/RF2010ROC.RData")
RF.2012.ROC <- data.frame(RF.FPs.2012,RF.TPs.2012)
save(RF.2012.ROC,file="workspaces/RF2012ROC.RData")

## Make graph
pdf("graphs/Random Forest ROC 2010.pdf",width = 7, height = 7,family = "Times")
plot(RF.FPs[,1],
     RF.TPs[,1],
     type = "l",
     col = "cadetblue1",
     xlim = c(0,1),
     ylim = c(0,1),
     main = "Random Forests ROC 2010",
     ylab = "True Positive Rate",
     xlab = "False Positive Rate"
     )
for (i in 2:graph.runs) {
  lines(RF.FPs[,i],
       RF.TPs[,i],
       col = c("cadetblue1")
       )
}
lines(RF.FPs.2012,
     RF.TPs.2012,
     type = "l",
     lwd = 2,
     col = "blue4"
)
lines(avg.FP,
      avg.TP,
      lty = "dashed",
      lwd = 2,
      col = c("blue4")
      )
abline(c(0,1),
       lty = 2
       )
points(1-RFresults2010["specificity",],
       RFresults2010["sensitivity",],
       pch = 19
)
text(x = 1-RFresults2010["specificity",]-.2,
     y = RFresults2010["sensitivity",],
     labels = "Actual 2010 Error Rate",
     pos = 2
)
segments(x0 = 1-RFresults2010["specificity",]-.2,
         y0 = RFresults2010["sensitivity",],
         x1 = 1-RFresults2010["specificity",],
         y1 = RFresults2010["sensitivity",]
         )
points(1-RFresults2012["specificity",],
       RFresults2012["sensitivity",],
       pch = 19
)
text(x = 1-RFresults2012["specificity",]-.2,
     y = RFresults2012["sensitivity",],
     labels = "Actual 2012 Error Rate",
     pos = 2
)
segments(x0 = 1-RFresults2012["specificity",]-.2,
         y0 = RFresults2012["sensitivity",],
         x1 = 1-RFresults2012["specificity",],
         y1 = RFresults2012["sensitivity",]
)
text.legend <- c("2010 Average ROC", 
                 "2012 ROC", 
                 "ROCs for 2010 CV Runs", 
                 "45 Degree Line")
cols.legend <- c("blue4","blue4","cadetblue1","black")
stys.legend <- c(2,1,1,2)
wds.legend <- c(2,2,1,1)
legend(.6,
       .4,
       text.legend,
       lty = stys.legend,
       col = cols.legend,
       lwd = wds.legend
)
## End graph
dev.off()
