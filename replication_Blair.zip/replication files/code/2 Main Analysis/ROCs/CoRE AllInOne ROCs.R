## Run Each Model to Get ROCs

source("code/2 Main Analysis/ROCs/CoRE Lasso ROC.R")
source("code/2 Main Analysis/ROCs/CoRE Random Forests ROC.R")
source("code/2 Main Analysis/ROCs/CoRE Neural Networks ROC.R")
source("code/2 Main Analysis/ROCs/CoRE Logit ROC.R")

## Plot all ROC Curves Together

load("workspaces/Lasso2010ROC.RData")
load("workspaces/Lasso2012ROC.RData")
load("workspaces/Lassoresults2010.Rdata")
load("workspaces/Lassoresults2012.Rdata")

load("workspaces/RF2010ROC.RData")
load("workspaces/RF2012ROC.RData")
load("workspaces/RFresults2010.Rdata")
load("workspaces/RFresults2012.Rdata")

load("workspaces/NN2010ROC.RData")
load("workspaces/NN2012ROC.RData")
load("workspaces/NNresults2010.Rdata")
load("workspaces/NNresults2012.Rdata")

load("workspaces/Logit2010ROC.RData")
load("workspaces/Logit2012ROC.RData")
load("workspaces/Logitresults2010.Rdata")
load("workspaces/Logitresults2012.Rdata")

pdf("graphs/ROCs 2010.pdf",width = 7, height = 7, family = "Times")
plot(Lasso.2010.ROC[,1],
     Lasso.2010.ROC[,2],
     type = "l",
     col = "gray70",
     xlim = c(0,1),
     ylim = c(0,1),
     lwd = 2,
     ylab = "True Positive Rate",
     xlab = "False Positive Rate"
)
lines(RF.2010.ROC[,1],
      RF.2010.ROC[,2],
      lty = 2,
      lwd = 2,
      col = c("gray60")
)
lines(NN.2010.ROC[,1],
      NN.2010.ROC[,2],
      lty = 6,
      lwd = 2,
      col = c("gray40")
)
lines(Logit.2010.ROC[,1],
      Logit.2010.ROC[,2],
      lty = 4,
      lwd = 2,
      col = c("gray20")
)
points(1-Lassoresults2010["specificity",],
       Lassoresults2010["sensitivity",],
       pch = 19
)
points(1-RFresults2010["specificity",],
       RFresults2010["sensitivity",],
       pch = 19
)
points(1-NNresults2010["specificity",],
       NNresults2010["sensitivity",],
       pch = 19
)
points(1-Logitresults2010["specificity",],
       Logitresults2010["sensitivity",],
       pch = 19
)
abline(c(0,1),
       lty = 3
)

text.2010 <- c("Lasso", 
               "Random Forest", 
               "Neural Network", 
               "Logit",
               "45 Degree Line",
               "Chosen Threshold")
cols.2010 <- c("gray70","gray60","gray40","gray20","black","black")
stys.2010 <- c(1,2,6,4,3,NA)
legend(.6,
       .4,
       text.2010,
       lty = stys.2010,
       col = cols.2010,
       lwd = c(2,2,2,2,1,NA),
       pch = c(NA,NA,NA,NA,NA,19)
)
dev.off()

#################################### 2012
pdf("graphs/ROCs 2012.pdf",width = 7, height = 7, family = "Times")
plot(Lasso.2012.ROC[,1],
     Lasso.2012.ROC[,2],
     type = "l",
     col = "gray70",
     xlim = c(0,1),
     ylim = c(0,1),
     lwd = 2,
     ylab = "True Positive Rate",
     xlab = "False Positive Rate"
)
lines(RF.2012.ROC[,1],
      RF.2012.ROC[,2],
      lty = 2,
      lwd = 2,
      col = c("gray60")
)
lines(NN.2012.ROC[,1],
      NN.2012.ROC[,2],
      lty = 6,
      lwd = 2,
      col = c("gray40")
)
lines(Logit.2012.ROC[,1],
      Logit.2012.ROC[,2],
      lty = 4,
      lwd = 2,
      col = c("gray20")
)
points(1-Lassoresults2012["specificity",],
       Lassoresults2012["sensitivity",],
       pch = 19
)
points(1-RFresults2012["specificity",],
       RFresults2012["sensitivity",],
       pch = 19
)
points(1-NNresults2012["specificity",],
       NNresults2012["sensitivity",],
       pch = 19
)
points(1-Logitresults2012["specificity",],
       Logitresults2012["sensitivity",],
       pch = 19
)
abline(c(0,1),
       lty = 3
)
text.2012 <- c("Lasso", 
               "Random Forest", 
               "Neural Network", 
               "Logit",
               "45 Degree Line",
               "Chosen Threshold")
cols.2012 <- c("gray70","gray60","gray40","gray20","black","black")
stys.2012 <- c(1,2,6,4,3,NA)
legend(.6,
       .4,
       text.2012,
       lty = stys.2012,
       col = cols.2012,
       lwd = c(2,2,2,2,1,NA),
       pch = c(NA,NA,NA,NA,NA,19)
)
dev.off()

## Calculate AUCs
k <- nrow(Lasso.2010.ROC)
base.Lasso.2010 <- Lasso.2010.ROC[1:k-1,1] - Lasso.2010.ROC[2:k,1] 
height.Lasso.2010 <- (Lasso.2010.ROC[2:k,2] + Lasso.2010.ROC[1:(k-1),2])/2
AUC.Lasso.2010 <- sum(base.Lasso.2010 * height.Lasso.2010)

k <- nrow(RF.2010.ROC)
base.RF.2010 <- RF.2010.ROC[1:k-1,1] - RF.2010.ROC[2:k,1] 
height.RF.2010 <- (RF.2010.ROC[2:k,2] + RF.2010.ROC[1:(k-1),2])/2
AUC.RF.2010 <- sum(base.RF.2010 * height.RF.2010)

k <- nrow(NN.2010.ROC)
base.NN.2010 <- NN.2010.ROC[1:k-1,1] - NN.2010.ROC[2:k,1] 
height.NN.2010 <- (NN.2010.ROC[2:k,2] + NN.2010.ROC[1:(k-1),2])/2
AUC.NN.2010 <- sum(base.NN.2010 * height.NN.2010)

k <- nrow(Logit.2010.ROC)
base.Logit.2010 <- Logit.2010.ROC[1:k-1,1] - Logit.2010.ROC[2:k,1] 
height.Logit.2010 <- (Logit.2010.ROC[2:k,2] + Logit.2010.ROC[1:(k-1),2])/2
AUC.Logit.2010 <- sum(base.Logit.2010 * height.Logit.2010)

## Calculate AUCs
k <- nrow(Lasso.2012.ROC)
base.Lasso.2012 <- Lasso.2012.ROC[1:k-1,1] - Lasso.2012.ROC[2:k,1] 
height.Lasso.2012 <- (Lasso.2012.ROC[2:k,2] + Lasso.2012.ROC[1:(k-1),2])/2
AUC.Lasso.2012 <- sum(base.Lasso.2012 * height.Lasso.2012)

k <- nrow(RF.2012.ROC)
base.RF.2012 <- RF.2012.ROC[1:k-1,1] - RF.2012.ROC[2:k,1] 
height.RF.2012 <- (RF.2012.ROC[2:k,2] + RF.2012.ROC[1:(k-1),2])/2
AUC.RF.2012 <- sum(base.RF.2012 * height.RF.2012)

k <- nrow(NN.2012.ROC)
base.NN.2012 <- NN.2012.ROC[1:k-1,1] - NN.2012.ROC[2:k,1] 
height.NN.2012 <- (NN.2012.ROC[2:k,2] + NN.2012.ROC[1:(k-1),2])/2
AUC.NN.2012 <- sum(base.NN.2012 * height.NN.2012)

k <- nrow(Logit.2012.ROC)
base.Logit.2012 <- Logit.2012.ROC[1:k-1,1] - Logit.2012.ROC[2:k,1] 
height.Logit.2012 <- (Logit.2012.ROC[2:k,2] + Logit.2012.ROC[1:(k-1),2])/2
AUC.Logit.2012 <- sum(base.Logit.2012 * height.Logit.2012)

AUC.2010 <- matrix(c(AUC.Lasso.2010,AUC.RF.2010,AUC.NN.2010,AUC.Logit.2010),nrow = 4)
AUC.2012 <- matrix(c(AUC.Lasso.2012,AUC.RF.2012,AUC.NN.2012,AUC.Logit.2012),nrow = 4)
AUCs <- cbind(AUC.2010,AUC.2012)
rownames(AUCs) <- c("Lasso", "Random Forests", "Neural Networks", "Logit")
colnames(AUCs) <- c("2010","2012")

xl.workbook.open("tables/raw output/AUCs.xlsx")
curfile<-xl.get.excel()
xl.write(AUCs,curfile[["Activesheet"]]$Cells(1,1), na = "", row.names=TRUE, col.names=TRUE)
xl.workbook.save("tables/raw output/AUCs.xlsx")
xl.workbook.close("AUCs")