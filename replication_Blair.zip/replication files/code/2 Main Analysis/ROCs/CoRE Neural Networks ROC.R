## SECTION 3.0: Random Forests ##
## SECTION 3.1: SIMULATED OUT-OF-SAMPLE TEST ##
load("workspaces/NNresults2010.Rdata")
load("workspaces/NNresults2012.Rdata")
ROC_seq = seq(from = 0, to = 1, by = 0.001)

## Specify number of trials		
CV.runs <- 200
graph.runs <- 20
J <- length(ROC_seq)
      
## Specify number of folds for CV     
K = 5
sampleSplit = c(0,round((nrow(testframe2)/K*c(seq(1:K)))))
## Define Vector for Results
NN.TPs <- matrix(data = NA, nrow = J, ncol = CV.runs)
NN.FPs <- matrix(data = NA, nrow = J, ncol = CV.runs)
      	
## Run 200 simulated out-of-sample tests					
## Note: The i loop runs CVs, the j loop tests all discrimination thresholds within each CV			
for(i in 1:CV.runs) {			
			set.seed(52+i)
	    ## First generate predicted probabilities    
      ## Create prediction vector to populate
	    pred.prob <- matrix(NA,nrow(testframe2))
      predictions <- matrix(NA,nrow(testframe2)) 
      ## Loop over folds
	    shuffle <- sample(1:nrow(testframe2),  dim(testframe2)[1],  replace=FALSE)	  
      for (k in 1:K) {      
      ## Divide sample        
        test <- testframe2[shuffle[(sampleSplit[k]+1):(sampleSplit[k+1])],]
        train <- testframe2[-shuffle[(sampleSplit[k]+1):(sampleSplit[k+1])],]        
        nn_model <- nnet(spec2010,
                         data=train,  
                         size = 5,  
                         decay = 0.1)  
        pred.prob[shuffle[(sampleSplit[k]+1):(sampleSplit[k+1])],] <- predict(nn_model,  test)
      }	  
	    for(j in 1:J){      
        predictions <- ifelse(pred.prob>ROC_seq[j],1,0)	  
        ## Find error rates  
        errors <- error.rates(testframe2[, "ytest"], predictions)				
			  # True Positives
			  NN.TPs[j, i]  <- errors$tp.rate						
			  # False Positives
			  NN.FPs[j, i]  <- errors$fp.rate			
      }
}
avg.FP = seq(from = 0, to = 1, by = 0.001)
bin.TP = matrix(data = NA, nrow = 1001, ncol = CV.runs)
round.FPs <- round(NN.FPs,2)
for (n in 1:CV.runs) {
  for (i in 1:1001) {
    j = i - 1
    find.fp <- ifelse(round.FPs[,n]==j/1000,1,0)
    bin.TP[i,n] <- mean(NN.TPs[find.fp==1,n])
  }
  bin.TP[,n] <- lin.interp(bin.TP[,n])
}
avg.TP <- rowMeans(bin.TP)

## 2012
NN.TPs.2012 <- c(rep(NA,J))
NN.FPs.2012 <- c(rep(NA,J))
##
set.seed(06511)    	
full.nn <- nnet(spec2010,
                data=testframe2,  size = 5,  decay = 0.1)
pred.prob.2012_NN <- predict(full.nn, newx = testframe2_e2)
for(j in 1:J){      
  predictions <- ifelse(pred.prob.2012_NN>ROC_seq[j],1,0)    
  ## Find error rates  
  errors <- error.rates(testframe2_e2[, "ytest"], predictions)				
  # True Positives
  NN.TPs.2012[j]  <- errors$tp.rate						
  # False Positives
  NN.FPs.2012[j]  <- errors$fp.rate			
}

NN.2010.ROC <- data.frame(avg.FP,avg.TP)
save(NN.2010.ROC,file="workspaces/NN2010ROC.RData")
NN.2012.ROC <- data.frame(NN.FPs.2012,NN.TPs.2012)
save(NN.2012.ROC,file="workspaces/NN2012ROC.RData")

## Make graph
pdf("graphs/Neural Network ROC 2010.pdf",width = 7, height = 7, family = "Times")
plot(NN.FPs[,i],
     NN.TPs[,i],
     type = "l",
     col = "cadetblue1",
     xlim = c(0,1),
     ylim = c(0,1),
     main = "Neural Network ROC 2010",
     ylab = "True Positive Rate",
     xlab = "False Positive Rate"
     )
for (i in 2:graph.runs) {
  lines(NN.FPs[,i],
       NN.TPs[,i],
       col = c("cadetblue1")
       )
}
lines(avg.FP,
      avg.TP,
      lwd = 2,
      lty = "dashed",
      col = c("blue4")
      )
lines(NN.FPs.2012,
     NN.TPs.2012,
     lwd = 2,
     type = "l",
     col = "blue4"
)
abline(c(0,1),
       lty = 2
       )
points(1-NNresults2010["specificity",],
       NNresults2010["sensitivity",],
       pch = 19
)
text(x = 1-NNresults2010["specificity",]+.2,
     y = NNresults2010["sensitivity",],
     labels = "Actual 2010 Error Rate",
     pos = 4
)
segments(x0 = 1-NNresults2010["specificity",]+.2,
         y0 = NNresults2010["sensitivity",],
         x1 = 1-NNresults2010["specificity",],
         y1 = NNresults2010["sensitivity",]
)
points(1-NNresults2012["specificity",],
       NNresults2012["sensitivity",],
       pch = 19
)
text(x = 1-NNresults2012["specificity",]-.1,
     y = NNresults2012["sensitivity",],
     labels = "Actual 2012 Error Rate",
     pos = 2
)
segments(x0 = 1-NNresults2012["specificity",]-.1,
         y0 = NNresults2012["sensitivity",],
         x1 = 1-NNresults2012["specificity",],
         y1 = NNresults2012["sensitivity",]
)
text.legend <- c("2010 Average ROC", 
                 "2012 ROC", 
                 "ROCs for 2010 CV Runs", 
                 "45 Degree Line")
cols.legend <- c("blue4","blue4","cadetblue1","black")
stys.legend <- c(2,1,1,2)
wds.legend <- c(2,2,1,1)
legend(.6,
       .4,
       text.legend,
       lty = stys.legend,
       col = cols.legend,
       lwd = wds.legend
)
## End graph
dev.off()