alpha = 0.95
load("workspaces/Lasso-optimallambda.RData")
load("workspaces/Lassoresults2010.Rdata")
load("workspaces/Lassoresults2012.Rdata")

ROC_seq = seq(from = 0, to = 1, by = 0.001)

## Specify number of trials		
CV.runs <- 200
graph.runs <- 20
J <- length(ROC_seq)

## 2010 ROC

## Specify number of folds for CV     
K = 5
sampleSplit = c(0,round((nrow(testframe2)/K*c(seq(1:K)))))
## Define Vector for Results
Lasso.TPs <- matrix(data = NA, nrow = J, ncol = CV.runs)
Lasso.FPs <- matrix(data = NA, nrow = J, ncol = CV.runs)
      	
## Run 200 simulated out-of-sample tests					
## Note: The i loop runs CVs, the j loop tests all discrimination thresholds within each CV			
for(i in 1:CV.runs) {			
			set.seed(52+i)
	    ## First generate predicted probabilities    
      ## Create prediction vector to populate
	    pred.prob <- matrix(NA,nrow(testframe2))
      predictions <- matrix(NA,nrow(testframe2)) 
      ## Loop over folds
	    shuffle <- sample(1:nrow(testframe2),  dim(testframe2)[1],  replace=FALSE)	  
      for (k in 1:K) {      
      ## Divide sample        
        test <- testframe2[shuffle[(sampleSplit[k]+1):(sampleSplit[k+1])],]
        train <- testframe2[-shuffle[(sampleSplit[k]+1):(sampleSplit[k+1])],]        
        lasso=glmnet(x = data.matrix(train[,predictors]), 
                   y = train[,"ytest"], family=c("binomial"), 
                   alpha = alpha, 
                   standardize = FALSE, 
                   lambda = lambda_star)
        pred.prob[shuffle[(sampleSplit[k]+1):(sampleSplit[k+1])],] <- predict(lasso, newx = data.matrix(test[,predictors]), type="response")
      }	  
	    for(j in 1:J){      
        predictions <- ifelse(pred.prob>ROC_seq[j],1,0)	  
        ## Find error rates  
        errors <- error.rates(testframe2[, "ytest"], predictions)				
			  # True Positives
			  Lasso.TPs[j, i]  <- errors$tp.rate						
			  # False Positives
			  Lasso.FPs[j, i]  <- errors$fp.rate			
      }
}
avg.FP = seq(from = 0, to = 1, by = 0.001)
bin.TP = matrix(data = NA, nrow = 1001, ncol = CV.runs)
round.FPs <- round(Lasso.FPs,2)
for (n in 1:CV.runs) {
  for (i in 1:1001) {
    j = i - 1
    find.fp <- ifelse(round.FPs[,n]==j/1000,1,0)
    bin.TP[i,n] <- mean(Lasso.TPs[find.fp==1,n])
  }
  bin.TP[,n] <- lin.interp(bin.TP[,n])
}
avg.TP <- rowMeans(bin.TP)

## 2012 ROC
Lasso.TPs.2012 <- c(rep(NA,J))
Lasso.FPs.2012 <- c(rep(NA,J))
##
fit=glmnet(x = data.matrix(testframe2[,predictors]), 
           y = testframe2[,"ytest"], family=c("binomial"), 
           alpha = alpha, 
           standardize = FALSE, 
           lambda = lambda_star)
pred2012=predict(fit, newx = data.matrix(testframe2_e2[,predictors]), type="response")
for(j in 1:J){      
  predictions <- ifelse(pred2012>ROC_seq[j],1,0)    
  ## Find error rates  
  errors <- error.rates(testframe2_e2[, "ytest"], predictions)				
  # True Positives
  Lasso.TPs.2012[j]  <- errors$tp.rate						
  # False Positives
  Lasso.FPs.2012[j]  <- errors$fp.rate			
}
Lasso.2010.ROC <- data.frame(avg.FP,avg.TP)
save(Lasso.2010.ROC,file="workspaces/Lasso2010ROC.RData")
Lasso.2012.ROC <- data.frame(Lasso.FPs.2012,Lasso.TPs.2012)
save(Lasso.2012.ROC,file="workspaces/Lasso2012ROC.RData")

## Make graph
pdf("graphs/Lasso ROC 2010.pdf",width = 7, height = 7, family = "Times")
plot(Lasso.FPs[,1],
     Lasso.TPs[,1],
     type = "l",
     col = "cadetblue1",
     xlim = c(0,1),
     ylim = c(0,1),
     main = "Lasso ROC 2010",
     ylab = "True Positive Rate",
     xlab = "False Positive Rate"
     )
for (i in 2:graph.runs) {
  lines(Lasso.FPs[,i],
       Lasso.TPs[,i],
       col = c("cadetblue1")
       )
}
lines(avg.FP,
      avg.TP,
      lwd = 2,
      col = c("blue4"),
      lty = "dashed"
      )
lines(Lasso.FPs.2012,
     Lasso.TPs.2012,
     type = "l",
     lwd = 2,
     col = "blue4"
)
abline(c(0,1),
       lty = 2
       )
points(1-Lassoresults2010["specificity",],
       Lassoresults2010["sensitivity",],
       pch = 19
)
text(x = 1-Lassoresults2010["specificity",]-.2,
     y = Lassoresults2010["sensitivity",],
     labels = "Actual 2010 Error Rate",
     pos = 2
)
segments(x0 = 1-Lassoresults2010["specificity",]-.2,
         y0 = Lassoresults2010["sensitivity",],
         x1 = 1-Lassoresults2010["specificity",],
         y1 = Lassoresults2010["sensitivity",])

points(1-Lassoresults2012["specificity",],
       Lassoresults2012["sensitivity",],
       pch = 19
       )
text(x = 1-Lassoresults2012["specificity",]-.2,
     y = Lassoresults2012["sensitivity",],
     labels = "Actual 2012 Error Rate",
     pos = 2
     )
segments(x0 = 1-Lassoresults2012["specificity",]-.2,
        y0 = Lassoresults2012["sensitivity",],
        x1 = 1-Lassoresults2012["specificity",],
        y1 = Lassoresults2012["sensitivity",])

text.legend <- c("2010 Average ROC", 
               "2012 ROC", 
               "ROCs for 2010 CV Runs", 
               "45 Degree Line")
cols.legend <- c("blue4","blue4","cadetblue1","black")
stys.legend <- c(2,1,1,2)
wds.legend <- c(2,2,1,1)
legend(.6,
       .4,
       text.legend,
       lty = stys.legend,
       col = cols.legend,
       lwd = wds.legend
)

## End graph
dev.off()