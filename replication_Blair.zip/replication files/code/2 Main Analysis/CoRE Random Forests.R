## SECTION 3.0: Random Forests ##

	## SECTION 3.1: SIMULATED OUT-OF-SAMPLE TEST ##
			ROC_seq = seq(from = -0.001, to = 1.001, by = 0.001)

		## Specify number of trials		
			CV.runs <- 200
			J <- length(ROC_seq)
      
    ## Specify number of folds for CV     
      K = 5
			sampleSplit = c(0,round((nrow(testframe2)/K*c(seq(1:K)))))
			
		## Define vectors of true positives, true negatives, false positives and false negatives		
			ROC_holder <- matrix(NA, ncol = 2, nrow = J)
			RF_predictions <- matrix(NA, ncol = 1, nrow = CV.runs)	
			rfList <- vector("list", CV.runs)
			rfList_ROCs <- vector("list", J)
			rf_preds <- matrix(NA,  ncol = 1,  nrow = CV.runs)
			rf_predstp <- matrix(NA,  ncol = 1,  nrow = CV.runs)
			rf_predstn <- matrix(NA,  ncol = 1,  nrow = CV.runs)
			rf_predsfptp <- matrix(NA,  ncol = 1,  nrow = CV.runs)
			rf_predsfntp <- matrix(NA,  ncol = 1,  nrow = CV.runs)
			rf_predsviolrate <- matrix(NA,  ncol = 1,  nrow = CV.runs)
			rf_predsfnrate <- matrix(NA,  ncol = 1,  nrow = CV.runs)
			rf_predsauc <- matrix(NA,  ncol = 1,  nrow = CV.runs)
			pred2012_RF = matrix(NA,  nrow = dim(testframe2_e2)[1],  ncol = CV.runs)	
			ROC_output_matrix <- matrix(NA, nrow = J, ncol = 9)
			opt.DT <- rep(NA, times = CV.runs)
			RF.TPs <- matrix(data = NA, nrow = J, ncol = CV.runs)
			RF.FPs <- matrix(data = NA, nrow = J, ncol = CV.runs)
			colnames(ROC_output_matrix) <- c("DT", "accuracy", "true.pos", "true.neg", "FPTP", "FNTP","Predviol","FN.Rate","AUC")
			
		## Run 200 simulated out-of-sample tests					
		## Note: The i loop runs CVs, the j loop tests all discrimination thresholds within each CV			
		for(i in 1:CV.runs) {
				
			set.seed(52+i)
	    ## First generate predicted probabilities    
      ## Create prediction vector to populate
	    pred.prob <- matrix(NA,nrow(testframe2))
      predictions <- matrix(NA,nrow(testframe2)) 
      ## Loop over folds
	    shuffle <- sample(1:nrow(testframe2),  dim(testframe2)[1],  replace=FALSE)	  
      for (k in 1:K) {      
      ## Divide sample        
        test <- testframe2[shuffle[(sampleSplit[k]+1):(sampleSplit[k+1])],]
        train <- testframe2[-shuffle[(sampleSplit[k]+1):(sampleSplit[k+1])],]
	      fit <- randomForest(spec2010, 
				  type = regression, importance = TRUE, 
          na.action = na.omit, ntree = 1000, maxnodes = 5, 
          sampsize = 24, 
          replace = FALSE, do.trace = FALSE , 
          data = train, forest = TRUE   
		    	)	
        pred.prob[shuffle[(sampleSplit[k]+1):(sampleSplit[k+1])],] <- as.numeric(predict(fit, newdata = data.matrix(test), type="response"))  
      }
	  
	  for(j in 1:J){      
      predictions <- ifelse(pred.prob>ROC_seq[j],1,0)	  
      ## Find error rates  
      errors <- error.rates(testframe2[, "ytest"], predictions)		
		  # Calculate errors for this DT run
      #"DT" 
			ROC_output_matrix[j, 1] <- ROC_seq[j]			
			#"accuracy", 
			ROC_output_matrix[j, 2] <- errors$success.rate			
			#"true.pos", 
			ROC_output_matrix[j, 3]  <- errors$tp.rate						
			# "true.neg", 
			ROC_output_matrix[j, 4]  <- errors$tn.rate			
			#"FPTP", 
			ROC_output_matrix[j, 5]  <- errors$fptp.ratio			
			#"FNTP"
			ROC_output_matrix[j, 6]  <- errors$fntp.ratio
    }

		## Populate vectors of true positive, true negative, false positive and false negative rates
    #subset the acc greater than 50%
    opt.holder <- ROC_output_matrix[ROC_output_matrix[, "accuracy"]>0.5, ]
    #indentify first row with max sensitivty (using rank as tie-breaker)
    max_sensitivity_ID = which(opt.holder[,"true.pos"] == max(opt.holder[,"true.pos"]) )[1]
    #save that row with opt. DT
    opt.DT[i] <- opt.holder[max_sensitivity_ID, 1]			
    print(i)
	}
  save(opt.DT,file="workspaces/Rf-optimalthreshhold.RData")
	load("workspaces/Rf-optimalthreshhold.RData")
  ## Take optimal threshhold
  DT_star <- mean(opt.DT)
  
  ## Estimate out of sample error  
	rf_results <- matrix(NA,  ncol = 10,  nrow = CV.runs)
      colnames(rf_results) <- c("Sensitivity",
                                "Specificity",
                                "Accuracy",
                                "FPTP",
                                "FNTP",
                                "Viol.Rate",
                                "FN",
                                "AUC",
                                "AUC-PR",
                                "Brier")
	for(i in 1:CV.runs) {			  
		  set.seed(52+i)			  
		  ## First generate predicted probabilities		  
		  ## Create prediction vector to populate
		  predictions <- matrix(NA,nrow(testframe2))		 
		  pred.prob <- matrix(NA,nrow(testframe2))		  
		  ## Loop over folds
		  shuffle <- sample(1:nrow(testframe2),  dim(testframe2)[1],  replace=FALSE)		  
		  for (k in 1:K) {
		    ## Divide sample		    
		    test <- testframe2[shuffle[(sampleSplit[k]+1):(sampleSplit[k+1])],]
		    train <- testframe2[-shuffle[(sampleSplit[k]+1):(sampleSplit[k+1])],]		    
		    fit <- randomForest(spec2010, 
		                        type = regression, importance = TRUE, 
		                        na.action = na.omit, ntree = 1000, maxnodes = 5, 
		                        sampsize = 24, 
		                        replace = FALSE, do.trace = FALSE , 
		                        data = train, forest = TRUE   
		    )	
		    predictions[shuffle[(sampleSplit[k]+1):(sampleSplit[k+1])],] <- ifelse(as.numeric(predict(fit, newdata = data.matrix(test)))>DT_star,1,0)
		    pred.prob[shuffle[(sampleSplit[k]+1):(sampleSplit[k+1])],] <- as.numeric(predict(fit, newdata = data.matrix(test))) 
		  }			
			## Define confusion matrix			
			errors <- error.rates(testframe2[, "ytest"], predictions)	
			## Populate vectors of true positive, true negative, false positive and false negative rates			
			rf_results[i, ] <- c(errors$tp.rate,
			                     errors$tn.rate,
			                     errors$success.rate,
			                     errors$fptp.ratio,
			                     errors$fntp.ratio,
			                     errors$pred.pos.rate,
			                     errors$fn.all.ratio,
			                     roc(testframe2[,"ytest"],pred.prob)$auc,
			                     pr.curve(testframe2[,"ytest"],pred.prob)$auc.integral,
			                     mean((pred.prob - testframe2[, "ytest"])^2))
			
	  }
		## Calculate the mean, median and standard deviation of the results across the 200 tests		
			mean.results = apply(rf_results, 2, mean)
			sd.results = apply(rf_results, 2, sd)			
      
		## Export results		
      RFresults2010 = matrix(NA,ncol=1,nrow=20)
      RFresults2010[c(1:10)*2-1,] <- apply(rf_results, 2, mean)
			RFresults2010[c(1:10)*2,] <- apply(rf_results, 2, sd)  		
			rownames(RFresults2010)[c(1:10)*2] <- paste(colnames(rf_results),
                                                  "(SD)",
                                                  sep = "")
			rownames(RFresults2010)[c(1:10)*2-1] <- colnames(rf_results) 
      
			save(RFresults2010, file = "workspaces/RFresults2010.Rdata")
			
			colnames(RFresults2010) <- c("Random Forests")
			xl.workbook.open("tables/raw output/Table 3.xlsx")
			curfile<-xl.get.excel()
			xl.write(RFresults2010,curfile[["Activesheet"]]$Cells(1,4), na = "", row.names=TRUE, col.names=TRUE)
			xl.workbook.save("tables/raw output/Table 3.xlsx")
			xl.workbook.close("Table 3")
      
	## SECTION 3.2: TRUE OUT-OF-SAMPLE TEST ##
		## Fit single random forest to entire 2008/2010 dataset
      # Save seed for use in ROC code (elsewhere)
#       rf.seed <- .Random.seed
#       save(rf.seed,file="workspaces/rf.seed.RData")
#       load("workspaces/rf.seed.RData")
#       set.seed(rf.seed)
      set.seed(150827)
			rf.full <- randomForest(spec2010, 
			                    type = regression, importance = TRUE, 
			                    na.action = na.omit, ntree = 1000, maxnodes = 5, 
			                    sampsize = 24, 
			                    replace = FALSE, do.trace = FALSE , 
			                    data = testframe2, forest = TRUE   
			)			
    save(rf.full,file="workspaces/Rf-model.RData")
		## Print importance scores from combined model      
			rf.ranking <- data.frame(rf.full["importance"][[1]][,1])
			save(rf.ranking,file="workspaces/Rf-rankings.RData")
		## Predict wave 3 violence using wave 2 risk factors and combined model	
			pred2012_RF = ifelse(as.numeric(predict(rf.full, newdata = data.matrix(testframe2_e2[, predictors])))>DT_star,1,0)
      predprob2012_RF = as.numeric(predict(rf.full, newdata = data.matrix(testframe2_e2[, predictors])))
		## Identify true positives, false positives, true negatives and false negatives
			errors.RF.2012 <- error.rates(testframe2_e2[, "ytest"], pred2012_RF)	
    ## Create ROC
			RF.TPs.2012 <- c(rep(NA,J))
			RF.FPs.2012 <- c(rep(NA,J))
			for(j in 1:J){      
			  predictions <- ifelse(predprob2012_RF>ROC_seq[j],1,0)    
			  ## Find error rates  
			  errors <- error.rates(testframe2_e2[, "ytest"], predictions)      	
			  # True Positives
			  RF.TPs.2012[j]  <- errors$tp.rate						
			  # False Positives
			  RF.FPs.2012[j]  <- errors$fp.rate			
			}
			AUC.RF.2012 <- sum((RF.FPs.2012[1:J-1] - RF.FPs.2012[2:J] )*(RF.TPs.2012[2:J] + RF.TPs.2012[1:(J-1)])/2)
			
		## Calculate accuracy, sensitivity and specificity rates
			RFresults2012 = rbind(errors.RF.2012$tp.rate, 
			                      errors.RF.2012$tn.rate, 
			                      errors.RF.2012$success.rate, 
			                      errors.RF.2012$fptp.ratio, 
			                      errors.RF.2012$fntp.ratio,
			                      errors.RF.2012$pred.pos.rate,
			                      errors.RF.2012$fn.all.ratio,
			                      roc(testframe2_e2[, "ytest"],predprob2012_RF)$auc,
			                      var(roc(as.factor(testframe2_e2[, "ytest"]),predprob2012_RF))^.5,
			                      pr.auc <- pr.curve(testframe2_e2[, "ytest"],predprob2012_RF)$auc.integral,
			                      brier.score <- mean((predprob2012_RF - testframe2_e2[, "ytest"])^2)
                            )
			
			rownames(RFresults2012) <- c("sensitivity",
			                             "specificity",
			                             "accuracy",
			                             "False.Pos/True.Pos",
			                             "False.Neg/True.Pos",
			                             "Predicted Violence Rate",
			                             "False Negatives",
			                             "AuC",
                                   "AUC (SD)",
                                   "AUC PR",
                                   "Brier"
			                              )
      
			colnames(RFresults2012) <- c("Random Forests")
      
			save(RFresults2012, file = "workspaces/RFresults2012.Rdata")
			
			xl.workbook.open("tables/raw output/Table 4.xlsx")
			curfile<-xl.get.excel()
			xl.write(RFresults2012,curfile[["Activesheet"]]$Cells(1,4), na = "", row.names=TRUE, col.names=TRUE)
			xl.workbook.save("tables/raw output/Table 4.xlsx")
			xl.workbook.close("Table 4")

