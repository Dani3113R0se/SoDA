  ## SECTION 4.0: NEURAL NETWORKS ##
  
  ## SECTION 4.1: SIMULATED OUT-OF-SAMPLE TEST ##  
  ## Specify number of trials  
  CV.runs <- 200
  
  ## Specify number of folds for CV  
  K = 5
  sampleSplit = c(0,round((nrow(testframe2)/K*c(seq(1:K)))))
  
  ## Specify Range of DTs
  ROC_seq = seq(from = -0.001, to = 1.001, by = 0.001)
  J <- length(ROC_seq)
  
  ## Define vectors of true positives, true negatives, false positives and false negatives  
  nn_model <- vector("list", CV.runs)	
  nnet_preds <- matrix(NA,  ncol = 1,  nrow = CV.runs)
  nnet_predstp <- matrix(NA,  ncol = 1,  nrow = CV.runs)
  nnet_predstn <- matrix(NA,  ncol = 1,  nrow = CV.runs)
  nnet_predsfptp <- matrix(NA,  ncol = 1,  nrow = CV.runs)
  nnet_predsfntp <- matrix(NA,  ncol = 1,  nrow = CV.runs)
  nnet_predsviolrate <- matrix(NA,  ncol = 1,  nrow = CV.runs)
  nnet_predsfnrate <- matrix(NA,  ncol = 1,  nrow = CV.runs)
  nnet_predsauc <- matrix(NA,  ncol = 1,  nrow = CV.runs)
  NN.TPs <- matrix(data = NA, nrow = J, ncol = CV.runs)
  NN.FPs <- matrix(data = NA, nrow = J, ncol = CV.runs)
  NN_predictions <- matrix(NA,  ncol = 1,  nrow = 16)
  ROC_output_matrix <- matrix(NA, nrow = J, ncol = 6)
  colnames(ROC_output_matrix) <- c("DT", "accuracy", "true.pos", "true.neg", "FPTP", "FNTP")
  opt.DT <- rep(NA, times = CV.runs)
  
  ## Define dataset  
  #data = cbind(outcome_2010_NN, data)  
  ## Run 200 simulated out-of-sample tests
  for(i in 1:CV.runs) {   
    set.seed(52+i)    
    ## First generate predicted probabilities   
    ## Create prediction vector to populate
    pred.prob <- matrix(NA,nrow(testframe2))
    predictions <- matrix(NA,nrow(testframe2))
    
    ## Loop over folds
    shuffle <- sample(1:nrow(testframe2),  dim(testframe2)[1],  replace=FALSE)    
    for (k in 1:K) {
      
      ## Divide sample      
      test <- testframe2[shuffle[(sampleSplit[k]+1):(sampleSplit[k+1])],]
      train <- testframe2[-shuffle[(sampleSplit[k]+1):(sampleSplit[k+1])],]
      
      nn_model <- nnet(spec2010,
                      data=train,  
                      size = 5,  
                      decay = 0.1)	
      pred.prob[shuffle[(sampleSplit[k]+1):(sampleSplit[k+1])],] <- predict(nn_model,  test)
  
    }
    
    for(j in 1:J){
      predictions <- ifelse(pred.prob>ROC_seq[j],1,0)
      ## Find error rates
      errors <- error.rates(testframe2[,"ytest"], predictions)
      # Calculate errors for this DT run
      #"DT" 
      ROC_output_matrix[j, 1] <- ROC_seq[j]
      #"accuracy", 
      ROC_output_matrix[j, 2] <- errors$success.rate
      #"true.pos", 
      ROC_output_matrix[j, 3]  <- errors$tp.rate
      # "true.neg", 
      ROC_output_matrix[j, 4]  <- errors$tn.rate
      #"FPTP", 
      ROC_output_matrix[j, 5]  <- errors$fptp.ratio
      #"FNTP"
      ROC_output_matrix[j, 6]  <- errors$fntp.ratio
    }
    
    ## Populate vectors of true positive, true negative, false positive and false negative rates    
    #subset the acc greater than 50%
    opt.holder <- ROC_output_matrix[ROC_output_matrix[, "accuracy"]>0.5, ]
    
    #indentify first row with max sensitivty (using rank as tie-breaker)
    max_sensitivity_ID = which(opt.holder[,"true.pos"] == max(opt.holder[,"true.pos"]) )[1]
    
    #save that row with opt. DT
    opt.DT[i] <- opt.holder[max_sensitivity_ID, 1]
    
    print(i)
  }
  save(opt.DT,file="workspaces/NN-optimalthreshhold.RData")
  load("workspaces/NN-optimalthreshhold.RData")
  ## Take optimal threshhold
  DT_star <- mean(opt.DT)
  ## Estimate out of sample error  
  nn_results <- matrix(NA,  ncol = 10,  nrow = CV.runs)
  colnames(nn_results) <- c("Sensitivity",
                            "Specificity",
                            "Accuracy",
                            "FPTP",
                            "FNTP",
                            "Viol.Rate",
                            "FN",
                            "AUC",
                            "AUC-PR",
                            "Brier")
  for(i in 1:CV.runs) {
    
    set.seed(52+i)    
    ## First generate predicted probabilities    
    ## Create prediction vector to populate
    predictions <- matrix(NA,nrow(testframe2))    
    pred.prob <- matrix(NA,nrow(testframe2))    
    ## Loop over folds
    shuffle <- sample(1:nrow(testframe2),  dim(testframe2)[1],  replace=FALSE)    
    for (k in 1:K) {
      ## Divide sample     
      test <- testframe2[shuffle[(sampleSplit[k]+1):(sampleSplit[k+1])],]
      train <- testframe2[-shuffle[(sampleSplit[k]+1):(sampleSplit[k+1])],]      
      nn_model <- nnet(spec2010,
                       data=train,  
                       size = 5,  
                       decay = 0.1)  
      predictions[shuffle[(sampleSplit[k]+1):(sampleSplit[k+1])],] <- ifelse(predict(nn_model,  test)>DT_star,1,0) 
      pred.prob[shuffle[(sampleSplit[k]+1):(sampleSplit[k+1])],] <- predict(nn_model,  test)      
    }    
    ## Define confusion matrix    
    errors <- error.rates(testframe2[,"ytest"], predictions)	
    
    ## Populate vectors of true positive, true negative, false positive and false negative rates    
    nn_results[i, ] <- c(errors$tp.rate,
                         errors$tn.rate,
                         errors$success.rate,
                         errors$fptp.ratio,
                         errors$fntp.ratio,
                         errors$pred.pos.rate,
                         errors$fn.all.ratio,
                         roc(testframe2[,"ytest"],pred.prob)$auc,
                         pr.curve(testframe2[,"ytest"],pred.prob)$auc.integral,
                         mean((pred.prob - testframe2[, "ytest"])^2))
  }

## Calculate the mean, median and standard deviation of the results across the 200 tests
  NNresults2010 = matrix(NA,ncol=1,nrow=20)
  NNresults2010[c(1:10)*2-1,] <- apply(nn_results, 2, mean)
  NNresults2010[c(1:10)*2,] <- apply(nn_results, 2, sd)  		
  rownames(NNresults2010)[c(1:10)*2] <- paste(colnames(nn_results),
                                              "(SD)",
                                              sep = "")
  rownames(NNresults2010)[c(1:10)*2-1] <- colnames(nn_results) 

colnames(NNresults2010) <- c("Neural Networks")

save(NNresults2010, file = "workspaces/NNresults2010.Rdata")  

xl.workbook.open("tables/raw output/Table 3.xlsx")
curfile<-xl.get.excel()
xl.write(NNresults2010,curfile[["Activesheet"]]$Cells(1,7), na = "", row.names=TRUE, col.names=TRUE)
xl.workbook.save("tables/raw output/Table 3.xlsx")
xl.workbook.close("Table 3")

## SECTION 4.2: TRUE OUT-OF-SAMPLE TEST ##
## Fit a single non-CV neural net
set.seed(126) 
full.nn <- nnet(spec2010,
            data=testframe2,  size = 5,  decay = 0.1)

## Generate predicted probabilities of wave 3 violence using wave 2 risk factors and coefficients from the single non-CV neural net 
pred.prob.2012_NN <- predict(full.nn, newx = testframe2_e2)

## Predict wave 3 violence if predicted probability > DT*
pred2012_NN <- ifelse(pred.prob.2012_NN > DT_star, 1, 0)

## Identify true positives, false positives, true negatives and false negatives
errors_NN_2012 <- error.rates(testframe2_e2[, "ytest"], pred2012_NN)
  
## Make ROC
NN.TPs.2012 <- c(rep(NA,J))
NN.FPs.2012 <- c(rep(NA,J))
for(j in 1:J){      
  predictions <- ifelse(pred.prob.2012_NN>ROC_seq[j],1,0)    
  ## Find error rates  
  errors <- error.rates(testframe2_e2[, "ytest"], predictions)    		
  # True Positives
  NN.TPs.2012[j]  <- errors$tp.rate						
  # False Positives
  NN.FPs.2012[j]  <- errors$fp.rate			
}
AUC.NN.2012 <- sum((NN.FPs.2012[1:J-1] - NN.FPs.2012[2:J] )*(NN.TPs.2012[2:J] + NN.TPs.2012[1:(J-1)])/2)
NN.roc.2012 <- roc(as.factor(testframe2_e2[, "ytest"]),pred.prob.2012_NN)
AUC.NN.2012.se <- var(NN.roc.2012)^.5
  
NNresults2012 = rbind(errors_NN_2012$tp.rate, 
                      errors_NN_2012$tn.rate, 
                      errors_NN_2012$success.rate, 
                      errors_NN_2012$fptp.ratio, 
                      errors_NN_2012$fntp.ratio,
                      errors_NN_2012$pred.pos.rate,
                      errors_NN_2012$fn.all.ratio,
                      NN.roc.2012$auc,
                      AUC.NN.2012.se,
                      pr.auc <- pr.curve(testframe2_e2[, "ytest"],pred.prob.2012_NN)$auc.integral,
                      brier.score <- mean((pred.prob.2012_NN - testframe2_e2[, "ytest"])^2)
                      )

rownames(NNresults2012) <- c("sensitivity",
                             "specificity",
                             "accuracy",
                             "False.Pos/True.Pos",
                             "False.Neg/True.Pos",
                             "Predicted Violence Rate",
                             "False Negatives",
                             "AuC",
                             "AUC SE",
                             "AUC - PR",
                             "Brier"
                              )
colnames(NNresults2012) <- c("Neural Networks")
  
save(NNresults2012, file = "workspaces/NNresults2012.Rdata")

xl.workbook.open("tables/raw output/Table 4.xlsx")
curfile<-xl.get.excel()
xl.write(NNresults2012,curfile[["Activesheet"]]$Cells(1,7), na = "", row.names=TRUE, col.names=TRUE)
xl.workbook.save("tables/raw output/Table 4.xlsx")
xl.workbook.close("Table 4")
