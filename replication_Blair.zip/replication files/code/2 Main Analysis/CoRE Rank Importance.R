## Rank Importance

load("workspaces/Lasso-rankings.Rdata")
load("workspaces/RF-rankings.Rdata")
load("workspaces/logit-rankings.Rdata")
logit.betas <- logit.betas[-1]
load("workspaces/LogitModel2010.Rdata")

## Get Rankings
Lasso.Ranks = matrix(NA,nrow=length(predictors), ncol=1)
RF.Ranks = matrix(NA,nrow=length(predictors), ncol=1)
Logit.Ranks = matrix(NA,nrow=length(predictors), ncol=1)
RF.Ranks[order(matrix(rf.ranking[,1], ncol=1), 
               decreasing=TRUE)]<- seq(1,length(order(matrix(rf.ranking[,1], ncol=1), 
                                                      decreasing=TRUE)),1)
Lasso.Ranks[order(ifelse(matrix(Lasso.betas!=0),
                         abs(matrix(Lasso.betas)),NA),
                  na.last=NA, decreasing=TRUE)]<- seq(1,length(order(ifelse(matrix(Lasso.betas!=0),
                                                                    abs(matrix(Lasso.betas)),NA),
                                                              na.last=NA, decreasing=TRUE)),1)

Logit.Ranks[order(ifelse(matrix(logit.betas!=0),
                   abs(matrix(logit.betas)),NA),
                   na.last=NA, decreasing=TRUE)] <-  seq(1,length(order(ifelse(matrix(logit.betas!=0),
                                                                    abs(matrix(logit.betas)),NA),
                                                                    na.last=NA, decreasing=TRUE)),1)
full.rankings <- data.frame(predictors,Lasso.Ranks,RF.Ranks, Logit.Ranks)
rownames(full.rankings) <-var.labels
sorted.rankings <- full.rankings[with(full.rankings, order(Lasso.Ranks, RF.Ranks)), ]

xl.workbook.open("tables/raw output/Table 6.xlsx")
curfile<-xl.get.excel()
xl.write(sorted.rankings,curfile[["Activesheet"]]$Cells(1,1), na = "", row.names=TRUE, col.names=TRUE)
xl.workbook.save("tables/raw output/Table 6.xlsx")
xl.workbook.close("Table 6")

# Sort Based on Random Forests

sorted.RF.rankings <- full.rankings[with(full.rankings, order(RF.Ranks)), ]

xl.workbook.open("tables/raw output/Table 6.xlsx")
curfile<-xl.get.excel()
xl.write(sorted.RF.rankings,curfile[["Activesheet"]]$Cells(1,8), na = "", row.names=TRUE, col.names=TRUE)
xl.workbook.save("tables/raw output/Table 6.xlsx")
xl.workbook.close("Table 6")


# Sort Based on Logit

sorted.Logit.rankings <- full.rankings[with(full.rankings, order(Logit.Ranks)), ]

xl.workbook.open("tables/raw output/Table 6.xlsx")
curfile<-xl.get.excel()
xl.write(sorted.Logit.rankings,curfile[["Activesheet"]]$Cells(1,15), na = "", row.names=TRUE, col.names=TRUE)
xl.workbook.save("tables/raw output/Table 6.xlsx")
xl.workbook.close("Table 6")

## Full Importance and Rankings
## 

full.importance <- data.frame(predictors,
                              Lasso.Ranks,
                              as.matrix(Lasso.betas),
                              RF.Ranks,
                              as.matrix(rf.ranking),
                              Logit.Ranks,
                              as.matrix(logit.betas),
                              as.matrix(summary(logit.full)$coefficients[-1,2]))
rownames(full.importance) <-var.labels

xl.workbook.open("tables/raw output/Rankings with Importance.xlsx")
curfile<-xl.get.excel()
xl.write(full.importance,curfile[["Activesheet"]]$Cells(1,1), na = "", row.names=TRUE, col.names=TRUE)
xl.workbook.save("tables/raw output/Rankings with Importance.xlsx")
xl.workbook.close("Rankings with Importance")

## Sort
sorted.rankings.scores <- full.importance[with(full.importance, order(Lasso.Ranks, RF.Ranks)), ]

xl.workbook.open("tables/raw output/Table 6 - Scores.xlsx")
curfile<-xl.get.excel()
xl.write(sorted.rankings.scores,curfile[["Activesheet"]]$Cells(1,1), na = "", row.names=TRUE, col.names=TRUE)
xl.workbook.save("tables/raw output/Table 6 - Scores.xlsx")
xl.workbook.close("Table 6 - Scores")

# Sort Based on Random Forests
sorted.RF.rankings.scores <- full.importance[with(full.importance, order(RF.Ranks)), ]
xl.workbook.open("tables/raw output/Table 6 - Scores.xlsx")
curfile<-xl.get.excel()
xl.write(sorted.RF.rankings.scores,curfile[["Activesheet"]]$Cells(1,16), na = "", row.names=TRUE, col.names=TRUE)
xl.workbook.save("tables/raw output/Table 6 - Scores.xlsx")
xl.workbook.close("Table 6 - Scores")

# Sort Based on Logit
sorted.Logit.rankings.scores <- full.importance[with(full.importance, order(Logit.Ranks)), ]
xl.workbook.open("tables/raw output/Table 6 - Scores.xlsx")
curfile<-xl.get.excel()
xl.write(sorted.Logit.rankings.scores,curfile[["Activesheet"]]$Cells(1,31), na = "", row.names=TRUE, col.names=TRUE)
xl.workbook.save("tables/raw output/Table 6 - Scores.xlsx")
xl.workbook.close("Table 6 - Scores")