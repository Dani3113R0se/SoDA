### Section 5.0
### 5.0 Logit  

## Define parameters of model
ROC_seq = c(0,seq(from = 0.01,  to = 0.4,  by = 0.01)^4,seq(from = 0.02,  to = 1,  by = .01))
## ^ Much of the variation in predicted probabilities happens close to zero, so we want to have
## a finer grid here. There isn't much variation at higher values, and we use a coarser grid
## there for speed.
J <- length(ROC_seq)
CV.runs = 200

## Specify number of folds for CV

## Define prediction formula to be used in all models
spec2010 <- as.formula(paste("factor(ytest)",paste(predictors, collapse=" + "), sep = "~", collapse=NULL))
K = 5
sampleSplit = c(0,round((nrow(testframe2)/K*c(seq(1:K)))))

# Define holder matrix for results from each run of loop
outputLogit = matrix(NA,  nrow = CV.runs,  ncol = 6)
colnames(outputLogit) = c("accuracy.rate",  "true.pos.rate",  "true.neg.rate",  "FPTP",  "FNTP",  "threshold")
Logit.TPs <- matrix(data = NA, nrow = J, ncol = CV.runs)
Logit.FPs <- matrix(data = NA, nrow = J, ncol = CV.runs)

##### Run a CV - loop to identify optimal discrimination threshold

## Run 200 simulated out-of-sample tests
for(i in 1:CV.runs) {
  set.seed(552+i)
  ## First generate predicted probabilities
  ## Create prediction vector to populate
  pred.prob <- matrix(NA,nrow(testframe2))
  predictions <- matrix(NA,nrow(testframe2))
  ## Loop over folds
  shuffle <- sample(1:nrow(testframe2),  dim(testframe2)[1],  replace=FALSE)
  for (k in 1:K) {
    ## Divide sample
    test <- testframe2[shuffle[(sampleSplit[k]+1):(sampleSplit[k+1])],]
    train <- testframe2[-shuffle[(sampleSplit[k]+1):(sampleSplit[k+1])],]
    # Estimate Logit Model
    logit.model <- glm(spec2010, data = train, family = "binomial") 
    pred.prob[shuffle[(sampleSplit[k]+1):(sampleSplit[k+1])],] <- predict(logit.model,  test, type="response")
  }
  ROC_resultsLogit <- matrix(NA,nrow=length(ROC_seq), ncol=6)
  colnames(ROC_resultsLogit) <- c("accuracy.rate","true.pos.rate","true.neg.rate","FPTP","FNTP","threshold")
  for(m in 1:length(ROC_seq)){
    pred2010_Logit_01 = ifelse(pred.prob > ROC_seq[m], 1, 0) 	
    errorsLogit = error.rates(testframe2[, "ytest"],  pred2010_Logit_01)
    ROC_resultsLogit[m, 1] <- errorsLogit$success.rate #accuracy.rate
    ROC_resultsLogit[m, 2] <- errorsLogit$tp.rate #true.pos.rate
    ROC_resultsLogit[m, 3] <- errorsLogit$tn.rate #true.neg.rate
    ROC_resultsLogit[m, 4] <- errorsLogit$fptp.ratio #FPTP
    ROC_resultsLogit[m, 5] <- errorsLogit$fntp #FNTP
    ROC_resultsLogit[m, 6] <- ROC_seq[m] #threshold
  }
  print(i)
  # subset the ROC results to those with accuracy > .5 
  ROC_resultsLogit = subset(ROC_resultsLogit,  ROC_resultsLogit[, "accuracy.rate"]>0.5)
  # now save the highest sensitivity model to our output table
  outputLogit[i, ] = matrix(ROC_resultsLogit[which(ROC_resultsLogit[,"true.pos.rate"] == 
                                              max(ROC_resultsLogit[, "true.pos.rate"])[1]),],ncol=6)[1,]
}
# Calculate our averaged optimal discrimination threshold
threshold_starLogit = mean(outputLogit[,"threshold"])
save(threshold_starLogit, file="workspaces/Logit_Threshold.RData")
load("workspaces/Logit_Threshold.RData")
##### Estimate out of sample error rate (2010)
logit_results <- matrix(NA,  ncol = 10,  nrow = CV.runs)
colnames(logit_results) <- c("Sensitivity",
                             "Specificity",
                             "Accuracy",
                             "FPTP",
                             "FNTP",
                             "Viol.Rate",
                             "FN",
                             "AUC",
                             "AUC-PR",
                             "Brier")
for(i in 1:CV.runs) {
  set.seed(552+i)
  ## First generate predicted probabilities
  ## Create prediction vector to populate
  predictions <- matrix(NA,nrow(testframe2))
  pred.prob <- matrix(NA,nrow(testframe2))
  ## Loop over folds
  shuffle <- sample(1:nrow(testframe2),  dim(testframe2)[1],  replace=FALSE)
  for (k in 1:K) {
    ## Divide sample
    test <- testframe2[shuffle[(sampleSplit[k]+1):(sampleSplit[k+1])],]
    train <- testframe2[-shuffle[(sampleSplit[k]+1):(sampleSplit[k+1])],]
    # Estimate Logit Model
    logit.model <- glm(spec2010, data = train, family = "binomial") 
    predictions[shuffle[(sampleSplit[k]+1):(sampleSplit[k+1])],] <- ifelse(predict(logit.model,  test, type="response")>threshold_starLogit,1,0) 
    pred.prob[shuffle[(sampleSplit[k]+1):(sampleSplit[k+1])],] <- predict(logit.model,  test, type="response")     
  }
  ## Define confusion matrix
  errors <- error.rates(testframe2[, "ytest"], predictions)  
  ## Populate vectors of true positive, true negative, false positive and false negative rates
  logit_results[i, ] <- c(errors$tp.rate,
                          errors$tn.rate,
                          errors$success.rate,
                          errors$fptp.ratio,
                          errors$fntp.ratio,
                          errors$pred.pos.rate,
                          errors$fn.all.ratio,
                          roc(testframe2[,"ytest"],pred.prob)$auc,
                          pr.curve(testframe2[,"ytest"],pred.prob)$auc.integral,
                          mean((pred.prob - testframe2[, "ytest"])^2))
}
## Calculate average accuracy statistics 

Logitresults2010 = matrix(NA,ncol=1,nrow=20)
Logitresults2010[c(1:10)*2-1,] <- apply(logit_results, 2, mean)
Logitresults2010[c(1:10)*2,] <- apply(logit_results, 2, sd)    	
rownames(Logitresults2010)[c(1:10)*2] <- paste(colnames(logit_results),
                                               "(SD)",
                                               sep = "")
rownames(Logitresults2010)[c(1:10)*2-1] <- colnames(logit_results) 


colnames(Logitresults2010) <- c("Logit (2010)")
save(Logitresults2010,file="workspaces/Logitresults2010.Rdata")

xl.workbook.open("tables/raw output/Table 3.xlsx")
curfile<-xl.get.excel()
xl.write(Logitresults2010,curfile[["Activesheet"]]$Cells(1,10), na = "", row.names=TRUE, col.names=TRUE)
xl.workbook.save("tables/raw output/Table 3.xlsx")
xl.workbook.close("Table 3")

##### Calculate 2012 Error Rates
# Fit a single glm model that will be used for prediction
logit.full <- glm(spec2010, data = testframe2, family = "binomial") 
save(logit.full,file="workspaces/LogitModel2010.Rdata")
### Save predictions_Logit_2012 for this model
predictions_Logit_2012 = as.matrix(predict(logit.full,  newx = data.matrix(testframe2_e2[, predictors]), type="response"))
### Save betas for this model
logit.betas <- coefficients(logit.full)
save(logit.betas, file = "workspaces/logit-rankings.Rdata")
# Use optimal averaged discrimination threshold to classify fitted values as 0-1
pred2012_Logit_01 = ifelse(predictions_Logit_2012> threshold_starLogit, 1, 0) 	
### Calculate true out of sample accuracy
performance_Logit_2012 = c()
errorsLogit = error.rates(testframe2_e2[, "ytest"],  pred2012_Logit_01)

## Create ROC
Logit.TPs.2012 <- c(rep(NA,J))
Logit.FPs.2012 <- c(rep(NA,J))
for(j in 1:J){      
  predictions <- ifelse(predictions_Logit_2012>ROC_seq[j],1,0)    
  ## Find error rates  
  errors <- error.rates(testframe2_e2[, "ytest"], predictions)      	
  # True Positives
  Logit.TPs.2012[j]  <- errors$tp.rate						
  # False Positives
  Logit.FPs.2012[j]  <- errors$fp.rate			
}
AUC.Logit.2012 <- sum((Logit.FPs.2012[1:J-1] - Logit.FPs.2012[2:J] )*(Logit.TPs.2012[2:J] + Logit.TPs.2012[1:(J-1)])/2)
Logit.roc.2012 <- roc(as.factor(testframe2_e2[, "ytest"]),predictions_Logit_2012)
AUC.Logit.2012.se <- var(Logit.roc.2012)^.5

# True out-of-sample test accuracy stats
# write.csv(as.matrix(fitLogit$beta[, 1]), file = "LogitBeta.csv")
Logitresults2012 = rbind(errorsLogit$tp.rate, 
                      errorsLogit$tn.rate, 
                      errorsLogit$success.rate, 
                      errorsLogit$fptp.ratio, 
                      errorsLogit$fntp.ratio,
                      errorsLogit$pred.pos.rate,
                      errorsLogit$fn.all.ratio,
                      Logit.roc.2012$auc,
                      AUC.Logit.2012.se,
                      pr.curve(testframe2_e2[, "ytest"],predictions_Logit_2012)$auc.integral,
                      mean((predictions_Logit_2012 - testframe2_e2[, "ytest"])^2)
)

rownames(Logitresults2012) <- c("sensitivity",
                                "specificity",
                                "accuracy",
                                "False.Pos/True.Pos",
                                "False.Neg/True.Pos",
                                "Predicted Violence Rate",
                                "False Negatives",
                                "AuC",
                                "AUC SE",
                                "AUC - PR",
                                "Brier"
)

colnames(Logitresults2012) <- c("Logit (2012)")
save(Logitresults2012,file="workspaces/Logitresults2012.Rdata")

xl.workbook.open("tables/raw output/Table 4.xlsx")
curfile<-xl.get.excel()
xl.write(Logitresults2012,curfile[["Activesheet"]]$Cells(1,10), na = "", row.names=TRUE, col.names=TRUE)
xl.workbook.save("tables/raw output/Table 4.xlsx")
xl.workbook.close("Table 4")