## SECTION 2.0: LASSO ##
## SECTION 2.1: SIMULATED OUT-OF-SAMPLE TEST ##

## Define parameters of model
alpha = 0.95
ROC_seq = seq(from = -0.001, to = 1.001, by = 0.001)
J <- length(ROC_seq)
CV.runs = 200

## Define matrix of predicted probabilities for each community for each of 200 trials
predProbMat = matrix(data = NA, nrow = dim(testframe2)[[1]], ncol = CV.runs)
colnames(predProbMat) = seq(from = 1, to = CV.runs, by = 1)

## Define matrix of results
max_sens = matrix(data = NA, ncol = 6, nrow = (length(ROC_seq)*CV.runs))
colnames(max_sens) = c("lambda","max_sensitivity","accuracy","specificity", "Threshold", "CV.run")

## Run 200 simulated out-of-sample tests. Within each test:
for(j in 1:CV.runs){
    set.seed(06510+j)
    ## Fit 5-fold lasso CV
    cv.fit.test = cv.glmnet(x = as.matrix(testframe2[,predictors]), 
                          y = as.matrix(testframe2[,"ytest"]), 
                          family=c("binomial"), alpha = alpha, 
                          standardize = FALSE, 
                          type.measure = "auc",
                          keep = TRUE, nfolds = 5)
    cv.fit.test$fit.preval
    ## Run a loop over many discrimination thresholds (DTs). Within each loop:
    max_sensitivity = c()
    Abs.diff = c()		
    for(i in 1:length(ROC_seq)){
        threshold = ROC_seq[i]
        ## Predict violence if predicted probability > DT
        pred2010_CV_01 = ifelse(cv.fit.test$fit.preval>threshold,1,0) 
        ## Get error rates
        errors <- error.rates(replicate(ncol(pred2010_CV_01),testframe2[,"ytest"]), pred2010_CV_01)
        ## Define matrix of results for 78 lambdas and DT = i
        new_data = as.matrix(cbind(cv.fit.test$lambda,errors$tp.rate, errors$success.rate, errors$tn.rate, ROC_seq[i]))
        colnames(new_data) = c("lambda","sensitivity","accuracy","specificity","threshold")
        ## Identify lambdas that produce accuracy rates higher than .5 for DT = i
        acc_ID = which(new_data[,"accuracy"] >= 0.5)
        ## Drop lambdas that produce accuracy rates lower than .5 for DT = i
        new_data2 = new_data[acc_ID,,drop=FALSE] 
        ## Identify lambda*(sens) that produces highest true positive rate for DT = i while maintaining accuracy above .5
        max_sensitivity_ID = which(new_data2[,"sensitivity"] == max(new_data2[,"sensitivity"]) )[1]
        ## Define matrix of results for lambda*(sens)
        max_sens[(length(ROC_seq) * (j-1) ) + i,] = c(new_data2[max_sensitivity_ID,],j)
    }
    print(j)
}

## Save results from optimal model #1 within each of the 200 simulated out-of-sample tests, where the optimal model #1 is defined by a lambda and DT that maximize sensitivity while maintaining accuracy above 50%

## Define matrix of optimal results

maxsens.vector = matrix(data = NA, nrow = CV.runs, ncol = dim(max_sens)[2])
colnames(maxsens.vector) = c("lambda","max_sensitivity","accuracy","specificity",  "Threshold", "CV.run")

## Identify optimal lambdas within each test

for(k in 1:CV.runs){
    holder1 = max_sens[which(max_sens[,"CV.run"]==k),]
    holder1 = as.matrix(na.omit(holder1))
    holder2 = which(holder1[,"max_sensitivity"] == max(holder1[,"max_sensitivity"] )     )
    holder2 = holder2[1]
    holder3 = holder1[holder2,]
    maxsens.vector[k,] = holder3 
}

## Calculate the mean, median and standard deviation of the optimal model across the 200 tests
max.mean.main.model0810 = apply(maxsens.vector, 2, mean)
main_model_0810_SD = apply(maxsens.vector, 2, sd)

## Identify the mean and median lambda* and DT*
lambda_star = max.mean.main.model0810[["lambda"]]
threshold_star = max.mean.main.model0810[["Threshold"]]

save(lambda_star,file="workspaces/Lasso-optimallambda.RData")
save(threshold_star,file="workspaces/Lasso-otimalDT.RData")
load("workspaces/Lasso-optimallambda.RData")
load("workspaces/Lasso-otimalDT.RData")

##### Estimate out of sample error rates

## Run 200 simulated out-of-sample tests  	
## Note: The i loop runs CVs, the j loop tests all discrimination thresholds within each CV
lasso_preds <- matrix(NA,  ncol = 10,  nrow = CV.runs)
Lasso.TPs <- matrix(data = NA, nrow = J, ncol = CV.runs)
Lasso.FPs <- matrix(data = NA, nrow = J, ncol = CV.runs)

for(i in 1:CV.runs) {
    set.seed(52+i)    
    cv.fit.test = cv.glmnet(x = as.matrix(testframe2[,predictors]), 
                          y = as.matrix(testframe2[,"ytest"]), 
                          family=c("binomial"), alpha = alpha, 
                          standardize = FALSE, 
                          type.measure = "auc", lambda = seq(lambda_star*10,
                                                             lambda_star,
                                                             -lambda_star),
                          keep = TRUE, nfolds = 5) 	
    pred2010_CV_01 = ifelse(cv.fit.test$fit.preval[,10]>threshold_star,1,0) 
    ## Define confusion matrix
    errors <- error.rates(testframe2[,"ytest"], pred2010_CV_01)	
    auc <- roc(testframe2[,"ytest"],cv.fit.test$fit.preval[,10])$auc
    pr.auc <- pr.curve(testframe2[,"ytest"],cv.fit.test$fit.preval[,10])$auc.integral
    brier.score <- mean((cv.fit.test$fit.preval[,10] - testframe2[, "ytest"])^2)
    ## Populate vectors of true positive, true negative, false positive and false negative rates
    lasso_preds[i,] <- c(errors$success.rate,
                          errors$tp.rate,
                          errors$tn.rate,
                          errors$fptp.ratio,
                          errors$fntp.ratio,
                          errors$pred.pos.rate,
                          errors$fn.all.ratio,
                          auc,
                          pr.auc,
                          brier.score)
    
}
## Calculate AUC
## Calculate the mean, median and standard deviation of the optimal model across the 200 tests
mean.stats.lasso <- apply(lasso_preds, 2, mean)
sd.stats.lasso <- apply(lasso_preds, 2, sd)
Lassoresults2010 = data.frame(rbind(mean.stats.lasso[2],
                               sd.stats.lasso[2],
                               mean.stats.lasso[3], 
                               sd.stats.lasso[3],
                               mean.stats.lasso[1], 
                               sd.stats.lasso[1],
                               mean.stats.lasso[4], 
                               sd.stats.lasso[4],
                               mean.stats.lasso[5], 
                               sd.stats.lasso[5],
                               mean.stats.lasso[6], 
                               sd.stats.lasso[6],
                               mean.stats.lasso[7], 
                               sd.stats.lasso[7],
                               mean.stats.lasso[8], 
                               sd.stats.lasso[8],
                               mean.stats.lasso[9], 
                               sd.stats.lasso[9],
                               mean.stats.lasso[10], 
                               sd.stats.lasso[10]))
rownames(Lassoresults2010) <- c("sensitivity",
                           "sensitivity (SD)",
                           "specificity",
                           "specificity (SD)",
                           "accuracy",
                           "accuracy (SD)",
                           "False.Pos/True.Pos",
                           "False.Pos/True.Pos (SD)",
                           "False.Neg/True.Pos",
                           "False.Neg/True.Pos (SD)",
                           "Total Predicted Violence",
                           "Total Predicted Violence (SD)",
                           "Total False Negatives",
                           "Total False Negatives (SD)",
                           "AUC",
                           "AUC (SD)",
                           "AUC (PR)",
                           "AUC (PR) (SD)",
                           "Brier Score",
                           "Brier Score (SD)")
colnames(Lassoresults2010) <- c("Lasso")

save(Lassoresults2010, file = "workspaces/Lassoresults2010.Rdata")

# Write results to excel file
xl.workbook.open("tables/raw output/Table 3.xlsx")
curfile<-xl.get.excel()
xl.write(Lassoresults2010,curfile[["Activesheet"]]$Cells(1,1), na = "", row.names=TRUE, col.names=TRUE)
xl.workbook.save("tables/raw output/Table 3.xlsx")
xl.workbook.close("Table 3")

## SECTION 2.2: TRUE OUT-OF-SAMPLE TEST ##
## Fit a single non-CV lasso using lambda*
set.seed(06511)
## Run glmnet over several lambdas
lambdas.fit=glmnet(x = data.matrix(testframe2[,predictors]), 
           y = testframe2[,"ytest"], family=c("binomial"), 
           alpha = alpha, 
           standardize = FALSE,
           lambda = .1/seq(from = 1, to = sqrt(.1/lambda_star), by = .002)^2)
## Get df, percentage of deviation explained, and lambdas
lambdas.range <- print(lambdas.fit)[which(print(lambdas.fit)[,3]>=lambda_star),]
## Restrict to deviations when a variable is added
incremental.deviance <- lambdas.range[which(lambdas.range[2:nrow(lambdas.range),1]!=lambdas.range[1:nrow(lambdas.range)-1,1]),]
## Add final row, with %variance for the entire model
incremental.deviance <- rbind(incremental.deviance,lambdas.range[nrow(lambdas.range),])
## Get changes in deviance explained for each variable
deviance.marginal <- as.matrix(incremental.deviance[2:6,2]-incremental.deviance[1:5,2])

rownames(deviance.marginal) <- c("Minority Tribe in Town Leadership",
                                  "Town Population",
                                  "Percent in Dominant Group",
                                  "Percent Believing Other Tribes are Violent",
                                  "Percent Who Contribute To Public Facilities")
colnames(deviance.marginal) <- "Reduction in deviance (% of null)"
# Export deviance scores to excel
xl.workbook.open("tables/raw output/Lasso variable Importance.xlsx")
curfile<-xl.get.excel()
xl.write(deviance.marginal,curfile[["Activesheet"]]$Cells(1,1), na = "", row.names=TRUE, col.names=TRUE)
xl.workbook.save("tables/raw output/Lasso variable Importance.xlsx")
xl.workbook.close("Lasso variable Importance")

fit=glmnet(x = data.matrix(testframe2[,predictors]), 
           y = testframe2[,"ytest"], family=c("binomial"), 
           alpha = alpha, 
           standardize = FALSE, 
           lambda = lambda_star)
## Save coefficients from single non-CV lasso
Lasso.betas<-fit$beta
save( Lasso.betas, file = "workspaces/Lasso-rankings.Rdata")
write.csv(as.matrix(fit$beta), file = "lasso_coefficients.csv")

## Plot coefficients from single non-CV lasso
    ## Keep non-zero coefficients
    rankData = as.matrix(fit$beta)
    dropDummy = ifelse(rankData[, "s0"]== 0, 1, 0 )
    rankData2 = as.matrix(rankData[which(dropDummy == 0), ])
    labData2 = as.matrix(var.labels[which(dropDummy == 0)])
    ## Sort positive and negative coefficients
    rankData3 = cbind(rankData2, rankData2[, 1], rankData2[, 1])
    colnames(rankData3) = c("coef", "posCoef", "negCoef")
    rankData3[rankData3[, "posCoef"] <= 0, "posCoef"] = NA
    rankData3[rankData3[, "negCoef"] >= 0, "negCoef"] = NA
    ## Rank order coefficients
    labData3 =  labData2[order(abs(rankData3[, "coef"]), decreasing = TRUE) ]  
    rankData3  = rankData3[order(abs(rankData3[, "coef"]), decreasing = TRUE), ]
    ## Define parameters of figure
    colorPos = "cornflowerblue"
    colorNeg = "darkgoldenrod1"
    numRows = dim(rankData3)[1]
    pdf("graphs/Lasso Coefficients.pdf",width = 7, height = 7)
    par(mar=c(5, 10.1, 4, 2)+0.1)
    plot(0, 0, type="n", xlab="Coefficient",  
        main = "Non-zero Lasso Coefficients", 
        ylab="", 
        xlim=c(0, 0.8), ylim=c(0, numRows),  axes=T,  
        cex.main = 0.8,  
        cex.lab = 0.8,  
        cex.axis = 0.8,  
        col.main = "grey31",  
        col.lab = "grey31" ,  
        cex.axis = 0.8,   col.axis = "grey31", 
        yaxt = "n")
    ## Populate figure
    verticalSpots = seq(from = 1,  to = dim(rankData3)[1],   by = 1)
        abline(h = seq(from = 1,  to = numRows),  lty = 3,  col = "gray")
    for(i in 1:dim(rankData3)[1]){
        points(x = abs(rankData3[i,  "posCoef"]),   y = verticalSpots[(dim(rankData3)[1]+1)-i]+0.13,     pch = "+",   col = "grey31")
        points(x = abs(rankData3[i,  "negCoef"]),   y = verticalSpots[(dim(rankData3)[1]+1)-i]+0.13,     pch = "-",   col = "grey31")
    }
    ## Add legend
    text(y = seq(numRows, 1, by=-1), par("usr")[1], labels = labData3, srt = 25, pos = 2, xpd = TRUE, cex = 0.6, col = "grey31")
    ## End graph
    dev.off()
## Generate predicted probabilities of wave 3 violence using wave 2 risk factors and coefficients from the single non-CV lasso
set.seed(06511)
pred2012=predict(fit, newx = data.matrix(testframe2_e2[,predictors]), type="response")

## Predict wave 3 violence if predicted probability > DT*
pred2012_01 = ifelse(pred2012>threshold_star,1,0) 

## Make ROC
Lasso.TPs.2012 <- c(rep(NA,J))
Lasso.FPs.2012 <- c(rep(NA,J))
for(j in 1:J){      
  predictions <- ifelse(pred2012>ROC_seq[j],1,0)    
  ## Find error rates  
  errors <- error.rates(testframe2_e2[, "ytest"], predictions)  			
  # True Positives
  Lasso.TPs.2012[j]  <- errors$tp.rate						
  # False Positives
  Lasso.FPs.2012[j]  <- errors$fp.rate			
}
AUC.Lasso.2012 <- sum((Lasso.FPs.2012[1:J-1] - Lasso.FPs.2012[2:J] )*(Lasso.TPs.2012[2:J] + Lasso.TPs.2012[1:(J-1)])/2)

Lasso.roc.2012 <- roc(as.factor(testframe2_e2[, "ytest"]),pred2012)
AUC.Lasso.2012.se <- var(Lasso.roc.2012)^.5

## Save predictions and predicted probabilities of wave 3 violence
mapping_data = cbind(testframe2_e2[,"core_comm_2012.commcode"],pred2012,pred2012_01)
colnames(mapping_data) = c("commcode", "pred_prob_violence", "pred_violence")
save(mapping_data,file="workspaces/mapping_data.RData")
write.csv(mapping_data, file = "lasso_predictions.csv")

## Define matrices for true positives, true negatives, false positives and false negatives
errors.2012 = error.rates(testframe2_e2[, "ytest"],pred2012_01)
auc <- roc(testframe2_e2[, "ytest"],pred2012)$auc
pr.auc <- pr.curve(testframe2_e2[, "ytest"],pred2012)$auc.integral
brier.score <- mean((pred2012 - testframe2_e2[, "ytest"])^2)

## Print results
Lassoresults2012 = data.frame(rbind(errors.2012$tp.rate, 
                                    errors.2012$tn.rate, 
                                    errors.2012$success.rate, 
                                    errors.2012$fptp.ratio, 
                                    errors.2012$fntp.ratio,
                                    errors.2012$pred.pos.rate,
                                    errors.2012$fn.all.ratio,
                                    auc,
                                    AUC.Lasso.2012.se,
                                    pr.auc,
                                    brier.score))
rownames(Lassoresults2012) <- c("sensitivity",
                                "specificity",
                                "accuracy",
                                "False.Pos/True.Pos",
                                "False.Neg/True.Pos",
                                "Predicted Violence Rate",
                                "False Negatives",
                                "AUC",
                                "AUC SE",
                                "AUC (PR)",
                                "Brier Score"
                                )
colnames(Lassoresults2012) <- c("Lasso")

save(Lassoresults2012, file = "workspaces/Lassoresults2012.Rdata")

xl.workbook.open("tables/raw output/Table 4.xlsx")
curfile<-xl.get.excel()
xl.write(Lassoresults2012,curfile[["Activesheet"]]$Cells(1,1), na = "", row.names=TRUE, col.names=TRUE)
xl.workbook.save("tables/raw output/Table 4.xlsx")
xl.workbook.close("Table 4")