#################################
## 1. Preamble
#################################

## Set your directory here
setwd("SET DIRECTORY HERE")

## Clear memory
rm(list = ls())

## Load Packages
source("code/1 Front Matter/CoRE Load Packages.R")

## Load Functions
source("code/1 Front Matter/CoRE Functions.R")

## Load Data
core_comm_2012 <- read.dta("Data/CoRE_comm-level_endline2-no missing.dta")

## Clean Data
source("code/1 Front Matter/CoRE Clean Data.R")

#################################
## 2. Main Analysis
#################################

## Table 1, Table 2
## Run Lasso Analysis
source("code/2 Main Analysis/CoRE Lasso.R")
## Run Random Forests
source("code/2 Main Analysis/CoRE Random Forests.R")
## Run Neural Networks
source("code/2 Main Analysis/CoRE Neural Networks.R")
## Run Benchmark Logit
source("code/2 Main Analysis/CoRE Logit.R")
## Figure 1, Figure 2
## Generate ROC Graphs
source("code/2 Main Analysis/ROCs/CoRE AllInOne ROCs.R")
## Table 3
source("code/2 Main Analysis/CoRE Rank Importance.R")